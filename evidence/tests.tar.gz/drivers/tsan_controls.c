#include <stdio.h>
#include <string.h>
#include <omp.h>
static int shared;
int main(int argc,char **argv) {
    if(argc!=2) return 1;
    if(!strcmp(argv[1],"startup")) { puts("startup");return 0; }
    if(!strcmp(argv[1],"clean")) {
        int slots[64]={0};long total=0;
        #pragma omp parallel for schedule(dynamic, 1) reduction(+:total) num_threads(4)
        for(int i=0;i<64;++i) { slots[i]=i;total+=i; }
        if(total!=2016) return 2;
        for(int i=0;i<64;++i) if(slots[i]!=i) return 3;
        puts("clean");return 0;
    }
    if(!strcmp(argv[1],"race")) {
        #pragma omp parallel num_threads(4)
        { shared=omp_get_thread_num(); }
        printf("race %d\n",shared);return 0;
    }
    return 4;
}
