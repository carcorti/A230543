#!/usr/bin/env python3
"""Independent integer oracle. Membership checks do not prove range coverage.

Trial division is deliberately independent of the C sieve, MR/rho and GMP.
For completeness checks, --low/--high explicitly enumerate a bounded interval.
"""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CAP = 10**16
PREFIX_SHA = '03efb10156a20d0f04fc7b1ff6f2f6de49b491ae8f7c88482475d61a964e5353'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def derivative(n):
    if n < 2:
        return 0
    remaining, answer, p = n, 0, 2
    while p <= remaining // p:
        exponent = 0
        while remaining % p == 0:
            remaining //= p
            exponent += 1
        answer += exponent * (n // p)
        p = 3 if p == 2 else p + 2
    if remaining > 1:
        answer += n // remaining
    return answer

def witness(n):
    a = derivative(n)
    b = derivative(a)
    square = n*n + a*a + b*b
    r = math.isqrt(square)
    return (n, a, b, r) if a > 0 and b > 0 and r*r == square else None

def rows(path, header=False):
    raw = path.read_bytes()
    require(raw.endswith(b'\n') and b'\r' not in raw and b'\0' not in raw, 'TSV framing')
    lines = raw.decode('ascii').splitlines()
    if header:
        require(lines[0].startswith('A230543-HITS-1\tcfg_sha='), 'hits identity')
        require(lines[1] == 'n\tx1\tx2\troot', 'hits columns')
        lines = lines[2:]
    result = []
    for line in lines:
        fields = line.split('\t')
        require(len(fields) == 4 and all(x.isascii() and x.isdecimal() for x in fields), 'row grammar')
        row = tuple(map(int, fields))
        require(2 <= row[0] <= CAP and all(0 < x < 2**64 for x in row), 'row domain')
        require(not result or result[-1][0] < row[0], 'row order')
        result.append(row)
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path)
    parser.add_argument('--low', type=int)
    parser.add_argument('--high', type=int)
    args = parser.parse_args()
    raw = (ROOT/'data/b230543.txt').read_bytes()
    require(hashlib.sha256(raw).hexdigest() == PREFIX_SHA, 'accepted prefix changed')
    known = [tuple(map(int, line.split())) for line in raw.splitlines() if line]
    require(len(known) == 22 and [i for i, _ in known] == list(range(1, 23)), 'prefix indexing')
    fixtures = rows(ROOT/'validation/reference.tsv')
    require({n for _, n in known}.issubset({x[0] for x in fixtures}), 'prefix fixtures missing')
    for row in fixtures:
        require(witness(row[0]) == row, 'independent fixture mismatch: '+str(row[0]))
    result = {'status':'PASS', 'fixtures':len(fixtures), 'prefix_terms':len(known),
              'method':'Python integer trial division and math.isqrt; no C backend',
              'coverage':'fixture membership only'}
    if args.run:
        found = rows(args.run/'hits.tsv', True)
        cfg = (args.run/'run.cfg').read_bytes()
        identity = (args.run/'hits.tsv').read_text().splitlines()[0].split('=')[1]
        require(hashlib.sha256(cfg).hexdigest() == identity, 'config digest')
        for row in found:
            require(witness(row[0]) == row, 'independent hit mismatch')
        result['run_hits'] = len(found)
        require((args.low is None) == (args.high is None), 'both interval bounds required')
        if args.low is not None:
            require(2 <= args.low <= args.high <= 10**10 and args.high-args.low < 40000, 'oracle interval budget')
            fields = dict(line.split('\t', 1) for line in cfg.decode('ascii').splitlines()[1:])
            require(int(fields['start']) == args.low and int(fields['end']) == args.high, 'interval identity')
            expected = [r for n in range(args.low, args.high+1) if (r := witness(n))]
            require(found == expected, 'complete interval disagreement')
            result['coverage'] = [args.low, args.high]
            result['tested_inputs'] = args.high-args.low+1
    else:
        require(args.low is None and args.high is None, 'interval needs --run')
    print(json.dumps(result, sort_keys=True))

if __name__ == '__main__':
    main()
