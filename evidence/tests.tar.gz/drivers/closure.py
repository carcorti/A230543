#!/usr/bin/env python3
"""Remaining bounded operational closure; unchanged candidate identity."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
from check import rows,require
import harden as h
import sympy
OUT=h.ROOT/'validation/local_v1/closure';OUT.mkdir(exist_ok=False)
EVENTS=[]
def run(args,expected=0,env=None):
 p=subprocess.run(list(map(str,args)),capture_output=True,text=True,timeout=30,env=env,cwd=h.ROOT)
 EVENTS.append({'command':list(map(str,args)),'expected':expected,'exit':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
 (OUT/'events.json').write_text(json.dumps(EVENTS,indent=2)+'\n');require(p.returncode==expected,p.stderr[-1000:]);return p
base=h.OUT/'small_t1'
# Existing config is the flock authority: shared readers coexist; writer excludes all.
fd=os.open(base/'run.cfg',os.O_RDONLY);before=h.fingerprint(base)
fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
for mode in ['status','verify','next']:
 p=run([h.EXE,mode,base],1);require('run busy' in p.stderr,'exclusive lock')
fcntl.flock(fd,fcntl.LOCK_UN);fcntl.flock(fd,fcntl.LOCK_SH|fcntl.LOCK_NB)
run([h.EXE,'status',base]);run([h.EXE,'verify',base]);run([h.EXE,'next',base],1)
os.close(fd);require(h.fingerprint(base)==before,'lock exclusion mutation')
# Identity failure in a disposable build, not canonical code.
build=OUT/'identity';build.mkdir()
for name in ['a230543.c','Makefile','a230543']:shutil.copy2(h.ROOT/'src'/name,build/name)
exe=build/'a230543';d=OUT/'identity_run';run([exe,'init',d,2,3,16384,1,1]);before=h.fingerprint(d)
for name in ['a230543.c','Makefile','a230543']:
 p=build/name;original=p.read_bytes();p.write_bytes(original+b'\n')
 run([exe,'verify',d],1);require(h.fingerprint(d)==before,'identity mismatch mutated state');p.write_bytes(original)
# Failed fsync cannot seal or advance an authoritative frontier.
lib=OUT/'fault.so';run(['gcc','-shared','-fPIC',h.ROOT/'validation/fault_fsync.c','-o',lib])
env={**os.environ,'LD_PRELOAD':str(lib)}
d=OUT/'io_run';run([h.EXE,'init',d,490,6500,16384,1,4]);before=h.fingerprint(d)
run([h.EXE,'next',d],1,env)
require(all(h.fingerprint(d)[k]==v for k,v in before.items()),'fsync failure durable change')
require(not (d/'s0000000000.sha256').exists(),'failed fsync seal')
run([h.EXE,'verify',d],2);run([h.EXE,'next',d]);run([h.EXE,'verify',d])
run(['python3',h.ROOT/'validation/check.py','--run',d,'--low',490,'--high',6500])
require(not any('.tmp.' in p.name for p in d.iterdir()),'stale temp cleanup')
d=OUT/'init_io_failure';run([h.EXE,'init',d,2,3,16384,1,1],1,env)
require(d.exists() and not list(d.iterdir()),'failed parent fsync authority')
# Actual maximum reserved path and first rejected path, with legal <=250-byte components.
path=OUT/'path_tree';path.mkdir()
while 4052-len(str(path))-1>253:
 path=path/('d'*250);path.mkdir()
path=path/('r'*(4052-len(str(path))-1));require(len(str(path))==4052,'path boundary construction')
run([h.EXE,'init',path,2,3,16384,1,1]);run([h.EXE,'next',path]);run([h.EXE,'verify',path])
rejected=str(path)+'x';p=run([h.EXE,'init',rejected,2,3,16384,1,1],1)
require('run directory path too long' in p.stderr and not Path(rejected).exists(),'reserved path rejection')
# High-cap adjacent negatives use SymPy factorizations independently of all C routines.
lo=10**16-1;expected=[];facts=[]
for n in [lo,lo+1]:
 f=sympy.factorint(n);a=sum(int(e)*(n//int(p)) for p,e in f.items());g=sympy.factorint(a);b=sum(int(e)*(a//int(p)) for p,e in g.items())
 from math import isqrt
 r=isqrt(n*n+a*a+b*b);yes=r*r==n*n+a*a+b*b and a>0 and b>0
 facts.append({'n':n,'d1':a,'d2':b,'square':bool(yes),'factorizations':[{str(p):int(e) for p,e in x.items()} for x in [f,g]]})
 if yes:expected.append((n,a,b,r))
require(rows(h.OUT/'cap/hits.tsv',True)==expected,'cap adjacent oracle')
(OUT/'cap_oracle.json').write_text(json.dumps(facts,indent=2)+'\n')
# Canonical framing and original-parent immutability checked freshly.
raw=(h.ROOT/'data/b230543.txt').read_bytes();require(raw.endswith(b'\n\n') and not raw.endswith(b'\n\n\n'),'b-file final blank record')
parent=Path('/home/carlo/MATH/OEIS/A249106/src')
for name,digest in [('a249106.c','38a7eebb6106f1e105115d6a78653ef02dcf5456dc9384e8ecff0351d1a62605'),('Makefile','509b95d2c4419b0c179cb87d66bc1fea218639ae036ce647bfd175e8c14310ed')]:
 require(hashlib.sha256((parent/name).read_bytes()).hexdigest()==digest,'parent identity changed')
(OUT/'summary.json').write_text(json.dumps({'status':'PASS','commands':len(EVENTS),'source_identity':json.load(open(h.OUT/'identity.json')),'boundaries':['flock','source/make/bin binding','fsync failure','temp cleanup','4052/4053 path','independent CAP-1/CAP negatives','b-file framing','parent unchanged']},indent=2)+'\n')
print('CLOSURE PASS')
