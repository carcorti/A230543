#!/usr/bin/env python3
"""Read-only11a audit of sealed coverage, positives, two bounded windows and classes.

No C execution, official search, rebuild or campaign input mutation.
Full negative coverage comes from reviewed C, not the bounded Python oracle.
"""
from decimal import Decimal
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT/path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


o = module('oracle', 'validation/check.py')
f = module('factor', 'validation/p1_20261007/audit.py')
c = module('control', 'validation/p3_plan_20261007/control.py')
require = o.require
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    run = Path(sys.argv[1]) if len(sys.argv) == 2 else HERE/'snapshot'
    protocol = json.loads((HERE/'protocol.json').read_text())
    plan = json.loads((ROOT/'outputs/A230543_1E11_plan.json').read_text())
    phase = plan['phases'][0]
    identity = sha(run/'run.cfg')
    require(identity == phase['expected_config_sha256'], 'planned cfg identity')
    cfg = o.config((run/'run.cfg').read_bytes())
    for key in ('start','end','block','group','threads'):
        require(cfg[key] == phase[key], 'phase cfg '+key)
    for key, path in [('source_sha','src/a230543.c'),('makefile_sha','src/Makefile'),
                      ('binary_sha','src/a230543')]:
        require(sha(ROOT/path) == cfg[key] == plan[key], 'production identity')
    found = o.rows(run/'hits.tsv',True,identity)
    o.sealed_coverage(run,cfg,identity,found)
    require([row[0] for row in found] == protocol['observed_positives'], 'observed native witnesses')
    require(len(o.lines((run/'manifest.tsv').read_bytes()))-2 == phase['segments'] ==
            protocol['native_sealed_segments'], 'sealed segment count')
    require([cfg['start'],cfg['end']] == protocol['native_interval'], 'native domain')
    prior_raw = (ROOT/'validation/p12_20261007/b230543.txt').read_bytes()
    require(prior_raw.endswith(b'\n\n') and not prior_raw.endswith(b'\n\n\n'), 'prior b-file framing')
    prior = [tuple(map(int,line.split())) for line in prior_raw.splitlines() if line]
    require(len(prior) == protocol['inherited_prefix_terms'] == 30 and
            [i for i,n in prior] == list(range(1,31)) and prior[-1][1] < cfg['start'] and
            cfg['start'] == 10**10+1, 'indexed prefix and gapless native join')
    prior_witness_raw = (ROOT/'validation/p12_20261007/witnesses.tsv').read_bytes()
    prior_witnesses = [tuple(map(int,line.split('\t'))) for line in
                       prior_witness_raw.decode('ascii').splitlines()[1:] if line]
    require([(row[0],row[1]) for row in prior_witnesses] == prior, 'prior witness indices')
    old_classes = json.loads((ROOT/'validation/family_r2_20261007/classes.json').read_text())['rows']
    require([tuple(row['witness']) for row in old_classes] ==
            [row[1:] for row in prior_witnesses], 'prior class witness mapping')
    expected_controls = {tuple(item['witness']) for item in json.loads(
        (ROOT/'validation/p3_plan_20261007/witnesses.json').read_text())['rows']
        if cfg['start'] <= item['witness'][0] <= cfg['end']}
    require(len(expected_controls) == 2 and expected_controls.issubset(set(found)), 'planned controls')
    positives = []
    for i,row in enumerate(found,31):
        n,a,b,r = row
        require(o.witness(n) == row, 'independent positive trial/isqrt')
        factors = [f.exact_factors(x) for x in (n,a,b)]
        require(sum(e*(n//p) for p,e in factors[0].items()) == a and
                sum(e*(a//p) for p,e in factors[1].items()) == b and
                n*n+a*a+b*b == r*r, 'additional exact factor-derived witness')
        g = math.gcd(*row); m,u,v,w = (x//g for x in row)
        lam = Fraction(u-o.derivative(m),m)
        require(Fraction(o.derivative(g),g) == lam and o.derivative(u)+lam*u == v and
                m*m+u*u+v*v == w*w, 'normalized derivative and square')
        den = f.exact_factors(lam.denominator)
        require(all(e==1 for e in den.values()), 'squarefree lambda denominator')
        residues = {p:(lam.numerator*pow(lam.denominator//p,-1,p))%p for p in den}
        alpha = sum((Fraction(e,p) for p,e in residues.items()),Fraction())
        core = math.prod(p**e for p,e in residues.items()); k = lam-alpha
        require(k.denominator == 1 and k >= 0, 'free prime degree')
        factors_g = f.exact_factors(g); residual = dict(factors_g)
        for p,e in residues.items():
            require(residual.get(p,0) >= e, 'core divides scale')
            residual[p] -= e
        require(all(e%p==0 for p,e in residual.items()) and
                sum(e//p for p,e in residual.items()) == k, 'prime scale reconstruction')
        params = [p for p,e in residual.items() for _ in range(e//p)]
        require(g == core*math.prod(p**p for p in params), 'scale identity')
        positives.append({'i':i,'witness':row,'factors_n_D_D2':factors,'Q':r*r,'gcd':g,
                          'normalized':[m,u,v,w],'lambda':str(lam),'core':core,
                          'free_prime_count':int(k),'prime_parameters':params,
                          'planned_control':row in expected_controls})
    extra = [item for item in positives if not item['planned_control']]
    require(len(extra)==1 and extra[0]['i']==33 and extra[0]['free_prime_count']==1 and
            extra[0]['lambda']=='1' and extra[0]['normalized']==
            [4802517313,5246382600,19023654540,20309803913], 'new primitive class')
    old_shapes = {tuple(row['normalized']) for row in old_classes}
    require(len(old_shapes)==7 and tuple(extra[0]['normalized']) not in old_shapes, 'new observed shape')
    require(protocol['windows'][0]['center']==found[0][0] and
            protocol['windows'][1]['center']==extra[0]['witness'][0], 'predeclared window mapping')
    windows=[]; distinct=set()
    for item in protocol['windows']:
        h=item['center']; low=max(cfg['start'],h-512); high=min(cfg['end'],h+512)
        records=[]; local_hits=[]
        for n in range(low,high+1):
            a=o.derivative(n); b=o.derivative(a); q=n*n+a*a+b*b; r=math.isqrt(q)
            accept=a>0 and b>0 and r*r==q
            records.append([n,a,b,q,r,accept]);distinct.add(n)
            if accept: local_hits.append((n,a,b,r))
        require(local_hits == [row for row in found if low<=row[0]<=high], 'window/sealed projection')
        require(len(records)==high-low+1==item['requested_count']==1025, 'actual window count')
        windows.append({'center':h,'reason':item['reason'],'actual_bounds':[low,high],
                        'requested_count':1025,'actual_count':len(records),
                        'positive_count':len(local_hits),'negative_count':len(records)-len(local_hits),
                        'columns':['n','D','D2','Q','floor_sqrt_Q','accept'],'records':records})
    require(sum(w['actual_count'] for w in windows)==len(distinct)==2050, 'distinct window coverage')
    raw_time=(run/'t11.tsv').read_bytes(); measured=c.timings(raw_time)
    require(measured['11b']==measured['11c']==0, '11a audit timing scope')
    time_rows=[line.split() for line in raw_time.decode('ascii').splitlines()]
    require(len(time_rows)==phase['segments'] and all(row[-1]=='0' for row in time_rows),
            'two successful native calls')
    manifest=[line.split('\t') for line in o.lines((run/'manifest.tsv').read_bytes())[2:]]
    for clock,state in zip(time_rows,manifest):
        require(abs(Decimal(clock[1])-Decimal(state[4])/10**9)<Decimal('0.10'),
                'recorded wall/internal elapsed consistency')
    states={p['name']:p['inputs'] for p in plan['phases']}; states['11a']=0
    forecast=c.forecast(plan,states,measured,'11b',{'11a':True,'11b':False,'11c':False})
    require(forecast['status']=='PASS', 'next-phase conditional forecast')
    print(json.dumps({'status':'PASS','sealed_to_end':True,'native_interval':[cfg['start'],cfg['end']],
        'native_segments':phase['segments'],'cfg_sha':identity,'native_inputs':phase['inputs'],
        'native_positives':len(found),'native_negatives':phase['inputs']-len(found),
        'inherited_prefix_terms':30,'indexed_new_terms':[[item['i'],item['witness'][0]] for item in positives],
        'maximal_contiguous_terms':33,'first_unresolved_index':34,'first_unresolved_lower_bound_strict':cfg['end'],
        'positive_witnesses':positives,'planned_controls_recovered':2,'additional_positive_count':1,
        'observed_primitive_shapes':8,'new_infinite_same_shape_family':{'primitive':extra[0]['normalized'],
        'lambda':'1','core':1,'free_prime_count':1,'formula':'4802517313*p^p, p prime',
        'smallest_member':19210069252,'next_prime_member':4802517313*3**3,
        'proof_scope':'D(t)=t for t=p^p; product rule yields scaled primitive chain and square for every prime. Existing rational-core theorem makes these the entire fixed-shape class; no absolute novelty claim.'},
        'windows':windows,'independent_window_distinct_inputs':len(distinct),
        'independent_window_positives':sum(w['positive_count'] for w in windows),
        'independent_window_negatives':sum(w['negative_count'] for w in windows),
        'wall_seconds':float(measured['11a']),'call_wall_seconds':[float(row[1]) for row in time_rows],
        'peak_rss_KiB':max(int(row[4]) for row in time_rows),'forecast_next_11b':forecast,
        'limitations':'Indices inherit accepted22-term baseline plus validatedP12. Full negative domain relies on reviewed exhaustive C; Python independently enumerates only2050 distinct inputs. Family is new relative to local seven shapes, not claimed historically novel. Snapshot timings are recorded next wall only; forecasts are empirical, not guarantees. No official continuation or canonical campaign-input mutation.'},sort_keys=True,indent=2))


if __name__ == '__main__':
    main()
