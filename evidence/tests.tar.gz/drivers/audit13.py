#!/usr/bin/env python3
"""Final13 audit on exact frozen copies (or --live), never an official next."""
from decimal import Decimal
import argparse
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(name,path):
    spec = importlib.util.spec_from_file_location(name,ROOT/path)
    obj = importlib.util.module_from_spec(spec); spec.loader.exec_module(obj)
    return obj


b = module('classify13','validation/11b_20261008/audit.py')
c = module('control13','validation/130_plan_20261009/control.py')
o,require = b.o,b.require
sha = lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__);parser.add_argument('--live',action='store_true')
    args = parser.parse_args();runroot = ROOT/'runs' if args.live else HERE/'snapshot'; run = runroot/'13'
    plan = json.loads((ROOT/'outputs/A230543_130_plan.json').read_text());phase = plan['phase']
    protocol = json.loads((HERE/'protocol.json').read_text())
    identity = sha(run/'run.cfg');cfg = o.config((run/'run.cfg').read_bytes())
    require(identity == phase['expected_config_sha256'],'planned cfg identity')
    for key in ('start','end','block','group','threads'):
        require(cfg[key] == phase[key],'planned cfg field')
    for key,path in [('source_sha','src/a230543.c'),('makefile_sha','src/Makefile'),('binary_sha','src/a230543')]:
        require(cfg[key] == plan[key] == sha(ROOT/path),'reviewed production identity')
    found = o.rows(run/'hits.tsv',True,identity);o.sealed_coverage(run,cfg,identity,found)
    require([r[0] for r in found] == protocol['expected_new_terms'],'observed positives')
    manifest = [r.split('\t') for r in o.lines((run/'manifest.tsv').read_bytes())[2:]]
    require(len(manifest) == phase['segments'] == 5,'five planned seals')
    prior = json.loads((ROOT/'validation/final_20261009/result.json').read_text())
    raw = (HERE/'before/data/b230543.txt').read_bytes()
    require(hashlib.sha256(raw).hexdigest() == plan['baseline_sha256'],'baseline39 exact identity')
    entries = o.indexed_prefix(raw)
    old_witnesses = [tuple(map(int,r.split())) for r in
        (HERE/'before/data/witnesses.tsv').read_text().splitlines()[1:] if r]
    require(prior['status'] == 'PASS' and len(entries) == prior['maximal_contiguous_terms'] == 39 and
            entries == [(p['i'],p['witness'][0]) for p in prior['all_classes']] and
            old_witnesses == [(p['i'],*p['witness']) for p in prior['all_classes']], 'prior39 alignment')
    require(prior['phases'][-1]['bounds'][1]+1 == cfg['start'] == 100000000001 and
            cfg['end'] == 130000000000, 'gapless predecessor join')
    controls = {tuple(p['witness']) for p in json.loads(
        (ROOT/'validation/130_plan_20261009/witnesses.json').read_text())['rows']}
    require(controls == set(found),'expected lambda1 control recovered')
    positives = [b.classify(40+i,row,controls) for i,row in enumerate(found)]
    require(len(positives) == 1 and positives[0]['lambda'] == '1' and
            positives[0]['prime_parameters'] == [3] and positives[0]['gcd'] == 27 and
            positives[0]['normalized'] == prior['all_classes'][32]['normalized'], 'same proved lambda1 family')
    for i,n,a,d2,r in old_witnesses:
        require(o.witness(n) == (n,a,d2,r),'inherited positive membership')
    classes = prior['all_classes']+positives
    entries += [(p['i'],p['witness'][0]) for p in positives]
    require([i for i,n in entries] == list(range(1,41)) and
            all(a[1]<z[1] for a,z in zip(entries,entries[1:])), 'contiguous40 indices/order')
    windows = []
    for item in protocol['independent_windows']:
        low,high = item['center']-512,item['center']+512
        require(cfg['start'] <= low <= high <= cfg['end'],'window domain')
        records=[];hits=[]
        for n in range(low,high+1):
            a=o.derivative(n);d2=o.derivative(a);q=n*n+a*a+d2*d2;r=math.isqrt(q)
            accept=a>0 and d2>0 and r*r==q;records.append([n,a,d2,q,r,accept])
            if accept:hits.append((n,a,d2,r))
        require(hits == [r for r in found if low <= r[0] <= high] and
                len(records) == item['requested_count'] == 1025,'independent window projection/count')
        windows.append({**item,'actual_bounds':[low,high],'actual_count':1025,
            'positive_count':len(hits),'negative_count':1025-len(hits),
            'columns':['n','D','D2','Q','floor_sqrt_Q','accept'],'records':records})
    inherited_windows = [json.loads((ROOT/'validation/p1_20261007/result.json').read_text())['neighborhood']]
    for p in ('validation/p12_20261007/result.json','validation/11a_20261007/result.json',
              'validation/11b_20261008/result.json','validation/final_20261009/result.json'):
        old = json.loads((ROOT/p).read_text());require(old['status']=='PASS','inherited window result')
        inherited_windows += old['windows']
    distinct = {}
    for window in inherited_windows+windows:
        low,high = window['actual_bounds'];records = window['records']
        require([r[0] for r in records]==list(range(low,high+1)) and len(records)==window['actual_count'] and
                sum(r[-1] for r in records)==window['positive_count'],'inherited raw window counts')
        for rec in records:
            n,a,d2,q,r,accept = rec
            require(q==n*n+a*a+d2*d2 and r*r<=q<(r+1)**2 and
                    accept==(a>0 and d2>0 and r*r==q),'inherited raw square record')
            require(n not in distinct or distinct[n]==rec,'overlap disagreement');distinct[n]=rec
    require(len(distinct)==10763 and sum(r[-1] for r in distinct.values())==11,'all campaign distinct bounded windows')
    clock = (runroot/'t13.tsv').read_bytes();measured,time_records = c.timings(clock)
    times = [r.split() for r in time_records]
    require(len(times)==len(manifest)==5 and all(r[-1]=='0' for r in times),'five successful calls')
    for timing,state in zip(times,manifest):
        require(abs(Decimal(timing[1])-Decimal(state[4])/10**9)<Decimal('0.1'),'clock/seal consistency')
    forecast = c.forecast(plan,0,True,measured);require(forecast['status']=='PASS','final additional envelope')
    singleton = [p['i'] for p in classes if p['free_prime_count']==0]
    require(singleton==[2,8,11,28,36,37] and len({tuple(p['normalized']) for p in classes})==10,'shape inventory40')
    # Exact adjacent upper witness from an already proved relation, with known-case replay.
    require(o.witness(512)==(512,2304,10752,11008),'F4 known-case replay')
    sparse=(244140625000,1098632812500,5126953125000,5249023437500)
    require(o.witness(sparse[0])==sparse and sparse[0]==2*2**2*5**15,'exact next upper witness')
    candidates=[]
    for label,m,k in [('F4',2,4),('F3',99,3),('F2',25557426,2),('lambda1',4802517313,1)]:
        for ps in itertools.combinations_with_replacement([2,3,5,7],k):
            n=m*math.prod(p**p for p in ps)
            if cfg['end']<n<=sparse[0]:candidates.append({'family':label,'n':n,'prime_parameters':ps})
    require(candidates==[{'family':'F4','n':sparse[0],'prime_parameters':(2,5,5,5)}], 'known-family candidates to sparse bound')
    bfile=(''.join(f'{i} {n}\n' for i,n in entries)+'\n').encode()
    wfile=('i\tn\tD\tD2\troot\n'+''.join('\t'.join(map(str,(p['i'],*p['witness'])))+'\n' for p in classes)+'\n').encode()
    afile=(HERE/'before/data/a230543.txt').read_bytes()[:-1]+(
        ' '.join(map(str,(40,*found[0])))+'\n\n').encode()
    require(bfile.startswith(raw[:-1]) and afile.startswith((HERE/'before/data/a230543.txt').read_bytes()[:-1]),
            'exact39 common data prefixes')
    for candidate in (bfile,wfile,afile):
        require(candidate.endswith(b'\n\n') and not candidate.endswith(b'\n\n\n'),'terminal LF LF')
    total = Decimal(str(prior['all_recorded_next_seconds']))+measured
    print(json.dumps({'status':'PASS','sealed_to_end':True,'cfg_sha':identity,'native_interval':[cfg['start'],cfg['end']],
        'native_segments':5,'native_inputs':phase['inputs'],'native_positives':1,'native_negatives':phase['inputs']-1,
        'inherited_terms':39,'indexed_new_terms':[[40,found[0][0]]],'maximal_contiguous_terms':40,
        'positive_witnesses':positives,'all_classes':classes,'primitive_shape_count':10,
        'infinite_class_member_terms':34,'singleton_indices':singleton,'windows':windows,
        'fresh_independent_inputs':1025,'fresh_independent_positives':1,'fresh_independent_negatives':1024,
        'all_campaign_bounded_distinct_inputs':len(distinct),'all_campaign_bounded_positives':11,
        'all_campaign_bounded_negatives':len(distinct)-11,'call_wall_seconds':[float(r[1]) for r in times],
        'wall_seconds':float(measured),'all_recorded_next_seconds':float(total),'peak_rss_KiB':max(int(r[4]) for r in times),
        'final_envelope':forecast,'all_native_inputs_since_accepted22':cfg['end']-408918816,
        'all_native_new_positives_since_accepted22':18,'all_native_segments_since_accepted22':22,
        'bfile_sha256':hashlib.sha256(bfile).hexdigest(),'witnesses_sha256':hashlib.sha256(wfile).hexdigest(),
        'afile_sha256':hashlib.sha256(afile).hexdigest(),
        'endpoint':{'status':'ENDPOINT DISCOVERY PASS','first_unresolved_index':41,
            'strict_lower_bound':cfg['end'],'exact_upper_bound':sparse[0],'sparse_witness':sparse,
            'family':'F4 parameters2,5,5,5; known-case replay at512',
            'known_family_candidates':candidates,'parameter_scope':'Four proved infinite observed shape classes; primes>=11 excluded to this bound because11^11>244140625000 even before seed.',
            'unmet_dependency':'Negative coverage on [130000000001,244140624999] or a new exact ordering proof',
            'terminal_challenge':'No additional contiguous term follows from admitted evidence.'},
        'limitations':'Ordered extension conditional on accepted22 baseline and reviewed C full-range negatives; not independent second enumeration. Prior bounded-window derivatives inherited, raw counts/squares/union reconciled. No exhaustive classification of all shapes, bibliographic novelty, official continuation or remote mutation.'},sort_keys=True,indent=2))


if __name__=='__main__':main()
