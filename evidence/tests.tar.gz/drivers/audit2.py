#!/usr/bin/env python3
"""Read-only final P1/P2 audit; exact positive arithmetic and bounded negatives.

Full negative coverage is the reviewed C enumeration, not this Python oracle.
Two predeclared 1025-input checks: first P2 hit and unexpected non-beacon hit.
No production changes, run commands, canonical data changes or assertions.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT/path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


oracle = module('reference', 'validation/check.py')
factor_oracle = module('p1_audit', 'validation/p1_20261007/audit.py')
require = oracle.require
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    base = Path(sys.argv[1]) if len(sys.argv) == 2 else ROOT/'runs'
    expected = {'runs/time.tsv'}
    phases, found = [], []
    for name, identity in [('first', '17de10b0ee4f28a483196d2cc2aff36ec7ebc49f80f95800bd99b04f6006cf60'),
                           ('1E10', 'daeacf098b33e720642e8cfeadf29190a87ad9167db4f070cb2ca3a43f7ce86b')]:
        run = base/name
        require(sha(run/'run.cfg') == identity, 'phase config identity')
        fields = oracle.config((run/'run.cfg').read_bytes())
        for key, path in [('source_sha', 'src/a230543.c'), ('makefile_sha', 'src/Makefile'),
                          ('binary_sha', 'src/a230543')]:
            require(sha(ROOT/path) == fields[key], 'production identity')
        rows = oracle.rows(run/'hits.tsv', True, identity)
        oracle.sealed_coverage(run, fields, identity, rows)
        count = len(oracle.lines((run/'manifest.tsv').read_bytes()))-2
        for filename in ['run.cfg', 'manifest.tsv', 'hits.tsv']:
            expected.add('runs/'+name+'/'+filename)
        for i in range(count):
            for suffix in ['tsv', 'sha256']:
                expected.add('runs/'+name+'/s'+format(i, '010x')+'.'+suffix)
        phases.append({'name':name, 'start':fields['start'], 'end':fields['end'],
                       'cfg_sha':identity, 'sealed_segments':count,
                       'input_count':fields['end']-fields['start']+1, 'hit_count':len(rows)})
        found.extend(rows)
    archive = {}
    for line in oracle.lines((base/'run.sha256').read_bytes()):
        require(re.fullmatch(r'[0-9a-f]{64}  runs/(?:first/[^/]+|1E10/[^/]+|time.tsv)', line),
                'archive grammar')
        digest, path = line.split('  ')
        require(path not in archive and path in expected, 'archive duplicate/unknown path')
        require(sha(base/path.removeprefix('runs/')) == digest, 'archived byte identity')
        archive[path] = digest
    require(set(archive) == expected and len(archive) == 15, 'archive full inventory')
    baseline = (ROOT/'data/b230543.txt').read_bytes()
    require(hashlib.sha256(baseline).hexdigest() == oracle.PREFIX_SHA, 'accepted baseline identity')
    prefix = [tuple(map(int, line.split())) for line in baseline.splitlines() if line]
    require(len(prefix) == 22 and [i for i, _ in prefix] == list(range(1, 23)), 'prefix indices')
    require(phases[0]['start'] == prefix[-1][1]+1 and
            phases[1]['start'] == phases[0]['end']+1 and phases[-1]['end'] == 10**10,
            'gapless phase joins')
    require([row[0] for row in found] == sorted({row[0] for row in found}), 'distinct ordered hits')
    beacons = {tuple(item['witness']) for item in json.loads(
        (ROOT/'validation/planning_20261006/beacons.json').read_text())['rows']
        if prefix[-1][1] < item['witness'][0] <= 10**10}
    require(len(beacons) == 7 and beacons.issubset(set(found)), 'all planned beacon witnesses')
    positive_evidence = []
    for row in found:
        require(oracle.witness(row[0]) == row, 'independent campaign positive')
        n, a, b, r = row
        fn, fa, fb = [factor_oracle.exact_factors(x) for x in (n, a, b)]
        require(sum(e*(n//p) for p, e in fn.items()) == a and
                sum(e*(a//p) for p, e in fa.items()) == b and n*n+a*a+b*b == r*r,
                'additional factor-derived positive')
        g = math.gcd(*row)
        positive_evidence.append({'row':row, 'factors':[fn,fa,fb], 'Q':r*r,
                                  'gcd':g, 'normalized': [x//g for x in row],
                                  'planned_beacon':row in beacons})
    additional = [row for row in found if row not in beacons]
    require(len(additional) == 1 and additional[0][0] == 4751984347, 'observed additional hit')
    centers = [next(row[0] for row in found if row[0] >= phases[1]['start']), additional[0][0]]
    windows, inputs = [], set()
    for h in centers:
        low, high = max(phases[1]['start'],h-512), min(phases[1]['end'],h+512)
        records, hits = [], []
        for n in range(low, high+1):
            a = oracle.derivative(n); b = oracle.derivative(a)
            q = n*n+a*a+b*b; r = math.isqrt(q)
            accept = a > 0 and b > 0 and r*r == q
            records.append([n,a,b,q,r,accept]); inputs.add(n)
            if accept: hits.append((n,a,b,r))
        require(hits == [row for row in found if low <= row[0] <= high], 'window projection equality')
        windows.append({'center':h, 'requested_count':1025, 'actual_bounds':[low,high],
                        'actual_count':len(records), 'positive_count':len(hits),
                        'negative_count':len(records)-len(hits), 'records':records})
    require(sum(w['actual_count'] for w in windows) == len(inputs) == 2050,
            'distinct nonoverlapping window count')
    fixture_rows = oracle.rows(ROOT/'validation/reference.tsv')
    old_shapes = {tuple(x//math.gcd(*row) for x in row) for row in fixture_rows
                  if row[0] in {n for _, n in prefix}}
    all_shapes = old_shapes | {tuple(item['normalized']) for item in positive_evidence}
    unexpected = next(item for item in positive_evidence if not item['planned_beacon'])
    require(len(old_shapes) == 6 and len(all_shapes) == 7, 'finite normalized shape count')
    require(unexpected['row'][0]%2 == 1 and unexpected['row'][0]%99 != 0,
            'exclusion from previously named seed families')
    print(json.dumps({'status':'PASS','phases':phases,'archive_sha256':archive,
        'archive_checksum_sha':sha(base/'run.sha256'), 'baseline_terms':22,
        'baseline_sha':oracle.PREFIX_SHA,'native_input_count':sum(p['input_count'] for p in phases),
        'native_negative_count':sum(p['input_count'] for p in phases)-len(found),
        'indexed_new_terms':[[23+i,row[0]] for i,row in enumerate(found)],
        'maximal_contiguous_terms':22+len(found),'first_unresolved_index':23+len(found),
        'first_unresolved_lower_bound_strict':10**10,'positive_witnesses':positive_evidence,
        'planned_beacon_count':len(beacons),'additional_hit_count':len(additional),
        'additional_hit_note':'Odd and not divisible by 99: outside F4, F3, F2 and contained F1. This is not a claim of absolute historical novelty or a new infinite family.',
        'normalized_shape_counts':{'accepted_prefix':len(old_shapes),'validated_prefix':len(all_shapes)},
        'windows':windows,'distinct_independent_window_inputs':len(inputs),
        'independent_window_positive_count':sum(w['positive_count'] for w in windows),
        'independent_window_negative_count':sum(w['negative_count'] for w in windows),
        'limitations':'Full-gap exclusion uses the reviewed exhaustive C run. Independent negative scope here is only the two 1025-input windows; the separate P1 513-input check is inherited. Accepted indices 1..22 are an input baseline. Hashes protect static trusted local bytes, not adversarial history. No historical novelty, infinite-family, publication, or new campaign claim.'},sort_keys=True,indent=2))


if __name__ == '__main__':
    main()
