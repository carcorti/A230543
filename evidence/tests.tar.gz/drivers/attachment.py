#!/usr/bin/env python3
"""Validate the documentary a-file against canonical b-file/witnesses and arithmetic."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('oracle',ROOT/'validation/check.py')
o = importlib.util.module_from_spec(spec)
spec.loader.exec_module(o)


def main():
    raw = (ROOT/'data/a230543.txt').read_bytes()
    o.require(raw.endswith(b'\n\n') and not raw.endswith(b'\n\n\n') and
              b'\r' not in raw and b'\0' not in raw, 'a-file LF LF framing')
    records = raw.decode('ascii').splitlines()
    o.require(records[:4] == ['# A230543: indexed Pythagorean quadruples.',
        '# i n D(n) D^2(n) root',
        '# n = a(i); D is the arithmetic derivative; root^2 = n^2 + D(n)^2 + D^2(n)^2.',
        '# Prepared by Carlo Corti, 2026-10-09.'], 'a-file documentary semantics/identity')
    rows = []
    for rec in records[4:-1]:
        fields = rec.split(' ')
        o.require(len(fields) == 5, 'a-file row grammar')
        rows.append(tuple(map(o.number,fields)))
    canonical = o.indexed_prefix((ROOT/'data/b230543.txt').read_bytes())
    o.require([(r[0],r[1]) for r in rows] == canonical and len(rows) == 40, 'a-file exact index mapping')
    existing = [tuple(map(int,r.split())) for r in
                (ROOT/'data/witnesses.tsv').read_text().splitlines()[1:] if r]
    o.require(rows == existing, 'a-file existing witnesses disagree')
    for i,n,a,b,r in rows:
        o.require(o.derivative(n) == a and o.derivative(a) == b and
                  n*n+a*a+b*b == r*r and o.witness(n) == (n,a,b,r), 'a-file arithmetic witness')
    print(json.dumps({'status':'PASS','rows':len(rows),'derivative_identities':2*len(rows),'square_identities':len(rows),
        'index_range':[1,len(rows)],'terminal_bytes':'LF LF','bytes':len(raw),
        'sha256':hashlib.sha256(raw).hexdigest(),
        'role':'documentary supporting attachment; no sparse unknown-index rows',
        'limitations':'Indexing inherited from canonical final campaign audit, not proved by membership alone. No upload or OEIS field proposal.'},sort_keys=True,indent=2))


if __name__ == '__main__': main()
