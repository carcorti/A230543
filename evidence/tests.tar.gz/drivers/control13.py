#!/usr/bin/env python3
"""Read-only control for the additional13 campaign; --next before each call.

No init/next, file repair, budget expansion, config edits or production rebuild.
"""
import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('old_control',ROOT/'validation/p3_plan_20261007/control.py')
prior = importlib.util.module_from_spec(spec); spec.loader.exec_module(prior)
require, native_status = prior.require, prior.native_status


def timings(raw):
    require((not raw or raw.endswith(b'\n')) and b'\r' not in raw and b'\0' not in raw, 'timing framing')
    seconds = Decimal(0); records = []
    for line in raw.decode('ascii').splitlines():
        fields = re.fullmatch(r'13\.next ([0-9]+(?:\.[0-9]+)?) ([0-9]+(?:\.[0-9]+)?) '
                              r'([0-9]+(?:\.[0-9]+)?) ([0-9]+) ([0-9]+)',line)
        require(fields is not None, 'timing grammar')
        require(int(fields[5]) in (0,2,130,137,143), 'unexpected next exit; preserve and diagnose')
        seconds += Decimal(fields[1]); records.append(line)
    return seconds, records


def forecast(plan, remaining, complete, measured, selected=False):
    phase = plan['phase']; covered = phase['inputs']-remaining
    require(0 <= remaining <= phase['inputs'] and measured >= 0, 'forecast domain')
    require(not covered or measured > 0, 'covered inputs have no recorded timing')
    rate = plan['rate_model']
    if covered: rate = min(rate,covered/float(measured))
    require(rate > 0, 'positive model rate')
    estimate = float(measured)+remaining/rate+plan['planning_pilot_seconds']+plan['non_next_allowance_seconds']
    result = {'status':'PASS' if estimate <= plan['technical_stop_seconds'] else 'STOP_REASSESS',
              'recorded_additional_next_seconds':float(measured),'remaining_inputs':remaining,
              'effective_conservative_model_rate':rate,'forecast_additional_seconds':estimate,
              'forecast_additional_hours':estimate/3600,
              'proposed_reassessment_ceiling_hours':plan['technical_stop_seconds']/3600,
              'scope':'Additional13 campaign only, pilots and reserved non-next allowance; previous15h scope closed; '
                      'not a guaranteed time bound or an expansion of user authorization',
              'complete':complete}
    if selected:
        require(not complete, '13 already COMPLETE; do not repeat next')
        width = phase['block']*phase['group']
        inputs = min(remaining,width-covered%width)
        result.update({'next_remaining_call_inputs':inputs,'next_seconds_estimate':inputs/rate,
                       'next_seconds_with_closure_reserve':inputs/rate+plan['per_call_closure_seconds']})
        if result['next_seconds_with_closure_reserve'] > plan['hourly_unit_seconds']:
            result.update({'status':'STOP_REASSESS','reason':'Observed slowdown exceeds the planned hourly envelope; '
                           'preserve run and reassess without resizing in place.'})
    return result


def command(argv):
    p = subprocess.run(argv,cwd=ROOT,capture_output=True,text=True,timeout=30)
    require(p.returncode == 0, p.stdout+p.stderr or 'command failed: '+str(argv))
    return p


def state(path, phase, binary_sha):
    require(not path.is_symlink() and path.is_dir(), 'initialized regular run directory required')
    require(hashlib.sha256((path/'run.cfg').read_bytes()).hexdigest() == phase['expected_config_sha256'],
            '13 config identity')
    p = command([str(ROOT/'src/a230543'),'status',str(path)])
    require(not p.stderr, 'native status diagnostic')
    remaining, complete = native_status(p.stdout,phase,binary_sha)
    elapsed_ns = int(re.search(r' elapsed_ns=([0-9]+) ',p.stdout)[1])
    return remaining, complete, elapsed_ns


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--next',action='store_true',dest='selected')
    args = parser.parse_args()
    command([sys.executable,'outputs/A230543_cli_preflight_20261006.py'])
    for manifest in ('outputs/A230543_130_inputs.sha256','outputs/A230543_130_prior.sha256',
                     'runs/run.sha256','runs/arc11.sha256'):
        command(['sha256sum','--check','--status',manifest])
    p = command(['./src/a230543','verify','runs/11c'])
    require(p.stdout.splitlines()[-1] == 'COMPLETE', 'audited predecessor11c must remain COMPLETE')
    plan = json.loads((ROOT/'outputs/A230543_130_plan.json').read_text())
    phase = plan['phase']; path = ROOT/phase['directory']
    require(not path.is_symlink(), 'run directory symlink')
    clock = ROOT/plan['new_time_file']; require(not clock.is_symlink(), 'timing symlink')
    measured, records = timings(clock.read_bytes() if clock.exists() else b'')
    if path.exists():
        remaining, complete, elapsed_ns = state(path,phase,plan['binary_sha'])
        require(Decimal(elapsed_ns)/10**9 <= measured+Decimal('0.1'),
                'native elapsed time exceeds recorded clock; preserve files and reconstruct missing records')
    else:
        require(not records, 'timing records without initialized13 run')
        remaining, complete = phase['inputs'], False
    result = forecast(plan,remaining,complete,measured,args.selected)
    result['initialized'] = path.exists()
    print(json.dumps(result,indent=2))
    if result['status'] != 'PASS': raise SystemExit(2)


if __name__ == '__main__':
    try: main()
    except (OSError,ValueError,KeyError,RuntimeError,subprocess.SubprocessError) as error:
        raise SystemExit('CONTROL FAIL: '+str(error))
