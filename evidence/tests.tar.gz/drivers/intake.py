#!/usr/bin/env python3
"""Fixed, bounded mathematical intake checks; not a production enumerator.

No extension interval is scanned. The seed rectangle is lambda=1..8,
m=1..20000. Trial division supplies every derivative; SymPy independently
rechecks positives and the accepted prefix. No bare asserts are used.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd, isqrt, prod
import hashlib
import itertools
import json
import time
import sympy

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
START = time.monotonic()

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def factors(n):
    result = {}
    p = 2
    while p <= n // p:
        while n % p == 0:
            result[p] = result.get(p, 0) + 1
            n //= p
        p = 3 if p == 2 else p + 2
    if n > 1:
        result[n] = result.get(n, 0) + 1
    return result

def derivative(n):
    return sum(e * (n // p) for p, e in factors(n).items())

def oracle(n):
    return sum(int(e) * (n // int(p)) for p, e in sympy.factorint(n).items())

def witness(n):
    d1 = derivative(n)
    d2 = derivative(d1)
    need((d1, d2) == (oracle(n), oracle(d1)), 'independent derivative mismatch')
    q = n*n + d1*d1 + d2*d2
    r = isqrt(q)
    need(r*r == q and min(n, d1, d2) > 0, 'invalid positive witness')
    g = gcd(gcd(n, d1), gcd(d2, r))
    eigen = prod(p ** (p*(e//p)) for p, e in factors(g).items())
    lam = sum(e//p for p, e in factors(g).items())
    return {'n':n, 'chain':[n,d1,d2], 'root':r, 'square_sum':q,
            'factors':[factors(n),factors(d1)], 'gcd':g,
            'gcd_log_derivative':str(Fraction(derivative(g),g)),
            'max_integer_eigen_divisor':eigen, 'lambda':lam,
            'shape':[str(Fraction(v,n)) for v in (n,d1,d2,r)]}

rows = [tuple(map(int, line.split())) for line in (ROOT/'data/b230543.txt').read_text().splitlines() if line.strip() and not line.startswith('#')]
need([i for i,n in rows] == list(range(1, len(rows)+1)), 'b-file indices')
known = [dict(index=i, **witness(n)) for i,n in rows]
seeds = []
for lam,m,r_expected in [(4,2,43),(3,99,1669),(1,102229704,981479836),(2,25557426,245369959)]:
    x1 = derivative(m)+lam*m
    x2 = derivative(x1)+lam*x1
    need(x1 == oracle(m)+lam*m and x2 == oracle(x1)+lam*x1, 'seed oracle')
    need(m*m+x1*x1+x2*x2 == r_expected*r_expected, 'seed square')
    seeds.append({'lambda':lam,'seed':m,'chain':[m,x1,x2],'root':r_expected,
                  'derivatives':[derivative(m),derivative(x1)],
                  'factorizations':[factors(m),factors(x1)],
                  'shape':[str(Fraction(v,m)) for v in (m,x1,x2,r_expected)]})
hits = []
tested_pairs = 0
for lam in range(1,9):
    for m in range(1,20001):
        if m % 1024 == 0:
            need(time.monotonic()-START < 60, 'bounded check deadline')
        x1 = derivative(m)+lam*m
        x2 = derivative(x1)+lam*x1
        q = m*m+x1*x1+x2*x2
        r = isqrt(q)
        tested_pairs += 1
        if r*r == q:
            need(x1 == oracle(m)+lam*m and x2 == oracle(x1)+lam*x1, 'rectangle positive oracle')
            hits.append({'lambda':lam,'seed':m,'chain':[m,x1,x2],'root':r,
                         'shape':[str(Fraction(v,m)) for v in (m,x1,x2,r)]})
families = {}
for h in hits:
    families.setdefault('|'.join(h['shape']), []).append([h['lambda'],h['seed']])
unindexed = {}
for seed in seeds:
    lam,m = seed['lambda'],seed['seed']
    for ps in itertools.combinations_with_replacement((2,3,5,7,11,13),lam):
        n = m * prod(p**p for p in ps)
        if rows[-1][1] < n <= 10**10:
            rec = unindexed.setdefault(n, witness(n))
            rec.setdefault('origins',[]).append({'lambda':lam,'seed':m,'primes':ps})
numeric=[]
for b in (711541152,10**10,10**11,10**12,10**14,10**16,10**17,5*10**17):
    u1 = b*(b.bit_length()-1)//2
    u2 = u1*(u1.bit_length()-1)//2
    q = b*b+u1*u1+u2*u2
    numeric.append({'cap':b,'bounds':[b,u1,u2],'bits':[v.bit_length() for v in (b,u1,u2)],
                    'square_sum_bound':q,'sum_bits':q.bit_length(),'root_bound':isqrt(q),
                    'root_bits':isqrt(q).bit_length(),'prime_table_root':isqrt(b),
                    'segment_count_group1_block_min':(b-1+16383)//16384})
result={'status':'PASS','scope':__doc__, 'sympy_version':sympy.__version__,
        'known':known,'seeds':seeds,'rectangle':{'lambdas':[1,8],'seeds':[1,20000],
        'tested_pairs':tested_pairs,'positive_pairs':len(hits),
        'negative_pairs':tested_pairs-len(hits),'hits':hits,'normalized_classes':families,
        'independence':'All rectangle negatives use trial division only; positives rechecked by SymPy. No production-code benchmark.'},
        'unindexed_positives_through_1E10':[unindexed[n] for n in sorted(unindexed)],
        'numeric_bounds':numeric,'elapsed_seconds':time.monotonic()-START,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'math_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'prefix_rows':len(known),'rectangle_hits':len(hits),
                  'rectangle_classes':len(families),'representatives':[v[0] for v in families.values()],
                  'unindexed':[r['n'] for r in result['unindexed_positives_through_1E10']],
                  'elapsed_seconds':result['elapsed_seconds']}))
