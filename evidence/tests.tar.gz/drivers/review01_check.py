#!/usr/bin/env python3
"""Finite review-01 coverage-gate regression; private evidence driver, not C tests."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'validation/review01'
OLD = ROOT/'validation/local_v1/matrix'
events = []

def require(ok, message):
    if not ok:
        raise RuntimeError(message)

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def execute(command, expected, label):
    start = time.monotonic()
    p = subprocess.run(list(map(str, command)), capture_output=True, text=True, timeout=30)
    event = dict(label=label, command=list(map(str, command)), expected=expected,
                 exit=p.returncode, stdout=p.stdout, stderr=p.stderr,
                 seconds=time.monotonic()-start)
    events.append(event)
    (OUT/'events.json').write_text(json.dumps(events, indent=2)+'\n')
    require(p.returncode == expected, label+': unexpected exit')
    return p.stdout

def clone(source, name):
    target = OUT/name
    shutil.copytree(source, target)
    return target

def bounds(d):
    fields = dict(line.split('\t') for line in (d/'run.cfg').read_text().splitlines()[1:])
    return int(fields['start']), int(fields['end'])

def check(d, expected, label, interval=True):
    for opt in ([], ['-O']):
        cmd = [sys.executable, *opt, ROOT/'validation/check.py', '--run', d]
        if interval:
            low, high = bounds(d)
            cmd += ['--low', low, '--high', high]
        raw = execute(cmd, expected, label+(' optimized' if opt else ' normal'))
        if expected == 0:
            data = json.loads(raw)
            if interval:
                require(data['sealed_to_end'] is True and data['coverage'] == [low, high], label)
            else:
                require(data['coverage'] == 'run membership only; no completion claim' and
                        'tested_inputs' not in data, label)
        else:
            require(not raw.strip(), label+': failure emitted a success/coverage record')

def rehash(d, mutate):
    """Alter a segment while updating both hash layers and manifest/seal."""
    p = d/'s0000000000.tsv'
    records = p.read_text().splitlines()
    records = mutate(records)
    prefix = ('\n'.join(records[:-1])+'\n').encode('ascii')
    raw = prefix+('state_sha\t'+sha(prefix)+'\n').encode('ascii')
    p.write_bytes(raw)
    digest = sha(raw)
    (d/'s0000000000.sha256').write_text(digest+'\n')
    manifest = (d/'manifest.tsv').read_text().splitlines()
    row = manifest[2].split('\t'); row[3] = digest
    manifest[2] = '\t'.join(row)
    (d/'manifest.tsv').write_text('\n'.join(manifest)+'\n')

def supplement():
    # Corrupt only the internal footer while retaining a valid outer hash/seal.
    d = clone(OLD/'new_gap_oracle', 'internal_footer_wrong')
    p = d/'s0000000000.tsv'
    records = p.read_text().splitlines(); records[-1] = 'state_sha\t'+'0'*64
    raw = ('\n'.join(records)+'\n').encode(); p.write_bytes(raw)
    digest = sha(raw); (d/'s0000000000.sha256').write_text(digest+'\n')
    records = (d/'manifest.tsv').read_text().splitlines()
    parts = records[2].split('\t'); parts[3] = digest; records[2] = '\t'.join(parts)
    (d/'manifest.tsv').write_text('\n'.join(records)+'\n')
    check(d, 1, 'internal footer wrong with valid outer digest')
    d = clone(OLD/'small_t4', 'manifest_swapped')
    records = (d/'manifest.tsv').read_text().splitlines()
    records[2], records[3] = records[3], records[2]
    (d/'manifest.tsv').write_text('\n'.join(records)+'\n')
    check(d, 1, 'manifest reordered')
    for name in ['gap_t1','gap_t4','gap_t8','beacon_t8','cap_t8']:
        check(ROOT/'validation/local_v1/calibration'/name, 0,
              'refresh pilot membership '+name, interval=False)
    for option in ([], ['-O']):
        for label, args in [('unpaired bounds',['--run',OUT/'init_only','--low','408918817']),
                            ('over-budget',['--run',OUT/'init_only','--low','2','--high','40002']),
                            ('bounds without run',['--low','2','--high','3'])]:
            execute([sys.executable,*option,ROOT/'validation/check.py',*args],1,label+str(option))

def main():
    check(OUT/'init_only', 1, 'init only')
    check(OUT/'init_only', 0, 'init membership', interval=False)
    # Authored structurally valid stopped-before-first-block fixture.
    stopped = clone(OUT/'init_only', 'stopped_zero')
    identity = sha((stopped/'run.cfg').read_bytes())
    low, high = bounds(stopped)
    prefix = (f'A230543-SEG-2\ncfg_sha\t{identity}\nid\t0000000000\n'
              f'low\t{low}\nhigh\t{high}\nfrontier\t{low-1}\nelapsed_ns\t0\nhits\t0\n').encode()
    (stopped/'s0000000000.tsv').write_bytes(prefix+('state_sha\t'+sha(prefix)+'\n').encode())
    execute([ROOT/'src/a230543','verify',stopped], 2, 'native authored stopped fixture')
    check(stopped, 1, 'stopped before first block')
    # A completed checkpoint without its seal is not completed coverage.
    unsealed = clone(OLD/'new_gap_oracle', 'unsealed')
    (unsealed/'s0000000000.sha256').unlink()
    manifest = (unsealed/'manifest.tsv').read_text().splitlines()[:2]
    (unsealed/'manifest.tsv').write_text('\n'.join(manifest)+'\n')
    execute([ROOT/'src/a230543','verify',unsealed], 2, 'native complete but unsealed')
    check(unsealed, 1, 'complete but unsealed')
    half = clone(OLD/'small_t4', 'half_sealed')
    (half/'s0000000001.tsv').unlink(); (half/'s0000000001.sha256').unlink()
    (half/'manifest.tsv').write_text('\n'.join((half/'manifest.tsv').read_text().splitlines()[:3])+'\n')
    (half/'hits.tsv').write_text('\n'.join((half/'hits.tsv').read_text().splitlines()[:-1])+'\n')
    execute([ROOT/'src/a230543','verify',half], 2, 'native half sealed')
    check(half, 1, 'half sealed')
    # This regression catches a missing segment-frontier check.
    forged = clone(OLD/'new_gap_oracle', 'premature_seal')
    def premature(records):
        records[5] = 'frontier\t408918816'
        return records
    rehash(forged, premature)
    execute([ROOT/'src/a230543','verify',forged], 1, 'native premature hash-valid seal')
    check(forged, 1, 'premature hash-valid seal')
    # Exact aggregate equality, not just the same total of witnesses.
    aggregate = clone(OLD/'small_t1', 'aggregate_wrong')
    records = (aggregate/'hits.tsv').read_text().splitlines()
    records[2] = '512\t2304\t10752\t11009'
    (aggregate/'hits.tsv').write_text('\n'.join(records)+'\n')
    check(aggregate, 1, 'wrong aggregate witness')
    short = clone(OLD/'small_t1', 'aggregate_short')
    (short/'hits.tsv').write_text('\n'.join((short/'hits.tsv').read_text().splitlines()[:2])+'\n')
    check(short, 1, 'short aggregate')
    mutations = {
        'manifest_crlf': ('manifest.tsv', lambda b: b.replace(b'\n',b'\r\n')),
        'manifest_nul': ('manifest.tsv', lambda b: b+b'\0\n'),
        'manifest_truncated': ('manifest.tsv', lambda b: b[:-1]),
        'manifest_wrong_identity': ('manifest.tsv', lambda b: b.replace(identity.encode(),b'0'*64)),
        'manifest_id': ('manifest.tsv', lambda b: b.replace(b'0000000000\t',b'0000000001\t')),
        'manifest_bounds': ('manifest.tsv', lambda b: b.replace(b'408919840',b'408919839')),
        'manifest_count': ('manifest.tsv', lambda b: b[:-2]+b'1\n'),
        'manifest_elapsed': ('manifest.tsv', lambda b: b.replace(b'885143',b'885144')),
        'segment_hash': ('s0000000000.tsv', lambda b: b.replace(b'frontier',b'frOntier')),
        'seal_truncated': ('s0000000000.sha256', lambda b: b[:-1]),
        'config_extra': ('run.cfg', lambda b: b+b'threads\t1\n'),
        'hits_empty': ('hits.tsv', lambda b: b''),
        'hits_wrong_identity': ('hits.tsv', lambda b: b.replace(b'cfg_sha=',b'cfg_sha=0')),
    }
    gap_identity = sha((OLD/'new_gap_oracle/run.cfg').read_bytes())
    identity = gap_identity
    for label, (filename, mutate) in mutations.items():
        d = clone(OLD/'new_gap_oracle', label)
        p = d/filename; original = p.read_bytes(); changed = mutate(original)
        require(changed != original, label+': mutation did not change bytes')
        p.write_bytes(changed)
        check(d, 1, label)
    segment_mutations = {
        'segment_identity': lambda records: [line.replace(gap_identity,'0'*64) for line in records],
        'segment_id': lambda records: [line.replace('id\t0000000000','id\t0000000001') for line in records],
        'segment_count': lambda records: [line.replace('hits\t0','hits\t1') for line in records],
        'segment_field_order': lambda records: records[:3]+[records[4],records[3]]+records[5:],
    }
    for label, mutate in segment_mutations.items():
        d = clone(OLD/'new_gap_oracle', label); rehash(d, mutate); check(d, 1, label)
    # Refresh just the checks depending on this validator, not native production tests.
    refreshed = []
    for name in ['small_t1','small_t4','small_t8','shifted','boundary','empty',
                 'new_gap_oracle','beacon_neighbors_oracle']:
        check(OLD/name, 0, 'refresh '+name); refreshed.append(name)
    for i in range(30):
        d = OLD/f'fixture_{i}'
        # Wide positive fixtures exceed the enumeration guard: membership only.
        low, high = bounds(d)
        check(d, 0, f'refresh fixture {i}', interval=high <= 10**10)
        refreshed.append(f'fixture_{i}')
    for name in ['cap','max_group']:
        check(OLD/name, 0, 'refresh '+name, interval=False); refreshed.append(name)
    for opt in ([], ['-O']):
        execute([sys.executable,*opt,ROOT/'validation/check.py'],0,'default fixtures '+str(opt))
    supplement()
    # Backwards-compatible helper API used by earlier private evidence drivers.
    spec = importlib.util.spec_from_file_location('current_checker',ROOT/'validation/check.py')
    module = importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    require(len(module.rows(OLD/'small_t1/hits.tsv',True)) == 5, 'helper API compatibility')
    old = json.loads((OLD/'events.json').read_text())
    cited = [{'event_index':i, **e} for i,e in enumerate(old) if 'new_gap_oracle' in str(e)]
    require(any(e['event_index']==257 and e['exit']==0 and '\nCOMPLETE\n' in e['stdout']
                for e in cited), 'historical gap native completion missing')
    (OUT/'historical_gap_completion.json').write_text(json.dumps({'source':'validation/local_v1/matrix/events.json',
       'source_sha256':sha((OLD/'events.json').read_bytes()), 'events':cited},indent=2)+'\n')
    summary = dict(status='PASS',scope='Validator-only finite remedy; no production rebuild or campaign',
        command_events=len(events),negative_state_cases=26,invalid_cli_cases=3,refreshed_runs=refreshed,
        normal_and_optimized=True,checker_sha256=sha((ROOT/'validation/check.py').read_bytes()),
        authored_states='stopped_zero; all other adverse states are explicit clones/mutations; native verify distinguishes partial/premature',
        observations_note='Refresh of historical domains adds no new mathematical input coverage',
        total_subprocess_seconds=sum(e['seconds'] for e in events))
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary))

if __name__ == '__main__':
    main()
