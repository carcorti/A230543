#!/usr/bin/env python3
"""Readonly completed11b audit; positives, classes, three bounded windows and clock.

Negative full-range coverage is reviewed C, not an independent second scan.
All outputs are private intermediate evidence; no official continuation.
"""
from decimal import Decimal
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT/path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


o = module('oracle', 'validation/check.py')
f = module('factors', 'validation/p1_20261007/audit.py')
c = module('control', 'validation/p3_plan_20261007/control.py')
require = o.require
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def classify(index, row, controls):
    n,a,b,r = row
    require(o.witness(n)==row, 'independent trial/isqrt witness')
    factors = [f.exact_factors(x) for x in (n,a,b)]
    require(sum(e*(n//p) for p,e in factors[0].items())==a and
            sum(e*(a//p) for p,e in factors[1].items())==b and
            n*n+a*a+b*b==r*r, 'factor-derived witness')
    g=math.gcd(*row); m,u,v,w=(x//g for x in row)
    lam=Fraction(u-o.derivative(m),m)
    require(Fraction(o.derivative(g),g)==lam and o.derivative(u)+lam*u==v and
            m*m+u*u+v*v==w*w, 'primitive derivative and square')
    den=f.exact_factors(lam.denominator)
    require(all(e==1 for e in den.values()), 'squarefree lambda denominator')
    residues={p:(lam.numerator*pow(lam.denominator//p,-1,p))%p for p in den}
    alpha=sum((Fraction(e,p) for p,e in residues.items()),Fraction())
    core=math.prod(p**e for p,e in residues.items()); k=lam-alpha
    require(k.denominator==1 and k>=0, 'free prime degree')
    residual=f.exact_factors(g)
    for p,e in residues.items():
        require(residual.get(p,0)>=e, 'core divides scale'); residual[p]-=e
    require(all(e%p==0 for p,e in residual.items()) and
            sum(e//p for p,e in residual.items())==k, 'prime parameters')
    params=[p for p,e in residual.items() for _ in range(e//p)]
    require(g==core*math.prod(p**p for p in params), 'scale reconstruction')
    return {'i':index,'witness':row,'factors_n_D_D2':factors,'Q':r*r,'gcd':g,
            'normalized':[m,u,v,w],'lambda':str(lam),'core':core,
            'free_prime_count':int(k),'prime_parameters':params,'planned_control':row in controls}


def main():
    run=Path(sys.argv[1]) if len(sys.argv)==2 else HERE/'snapshot'
    protocol=json.loads((HERE/'protocol.json').read_text())
    plan=json.loads((ROOT/'outputs/A230543_1E11_plan.json').read_text())
    phase=next(p for p in plan['phases'] if p['name']==protocol['phase'])
    raw=(run/'run.cfg').read_bytes();identity=sha(run/'run.cfg');cfg=o.config(raw)
    require(identity==phase['expected_config_sha256'], 'planned config hash')
    for key in ('start','end','block','group','threads'):
        require(cfg[key]==phase[key], 'planned config field')
    for key,path in [('source_sha','src/a230543.c'),('makefile_sha','src/Makefile'),
                     ('binary_sha','src/a230543')]:
        require(sha(ROOT/path)==cfg[key]==plan[key], 'production identity')
    found=o.rows(run/'hits.tsv',True,identity);o.sealed_coverage(run,cfg,identity,found)
    require([row[0] for row in found]==protocol['observed_positives'] and
            [cfg['start'],cfg['end']]==protocol['native_interval'], 'observed domain')
    manifest=[line.split('\t') for line in o.lines((run/'manifest.tsv').read_bytes())[2:]]
    require(len(manifest)==phase['segments']==protocol['native_sealed_segments'], 'sealed count')
    prior_dir=ROOT/protocol['prior_directory']; prior_result=json.loads((prior_dir/'result.json').read_text())
    prior_raw=(prior_dir/'b230543.txt').read_bytes()
    require(prior_raw.endswith(b'\n\n') and not prior_raw.endswith(b'\n\n\n'), 'prior framing')
    prior=[tuple(map(int,line.split())) for line in prior_raw.splitlines() if line]
    nprior=protocol['inherited_prefix_terms']
    require(len(prior)==nprior==prior_result['maximal_contiguous_terms']==33 and
            [i for i,n in prior]==list(range(1,nprior+1)) and
            prior_result['native_interval'][1]+1==cfg['start'] and prior[-1][1]<cfg['start'],
            'inherited indices and gapless completed-domain join')
    prior_witnesses=[tuple(map(int,line.split('\t'))) for line in
                     (prior_dir/'witnesses.tsv').read_text().splitlines()[1:] if line]
    require([(row[0],row[1]) for row in prior_witnesses]==prior, 'prior witness index mapping')
    old_classes=json.loads((ROOT/'validation/family_r2_20261007/classes.json').read_text())['rows']
    inherited=old_classes+prior_result['positive_witnesses']
    require([row['i'] for row in inherited]==list(range(1,nprior+1)) and
            [tuple(row['witness']) for row in inherited]==[row[1:] for row in prior_witnesses],
            'prior class alignment')
    controls={tuple(item['witness']) for item in json.loads(
        (ROOT/'validation/p3_plan_20261007/witnesses.json').read_text())['rows']
        if cfg['start']<=item['witness'][0]<=cfg['end']}
    require(len(controls)==2 and controls.issubset(set(found)), 'planned controls')
    positives=[classify(nprior+i+1,row,controls) for i,row in enumerate(found)]
    extra=[p for p in positives if not p['planned_control']]
    old_shapes={tuple(p['normalized']) for p in inherited}
    require(len(old_shapes)==8 and len(extra)==2 and [p['i'] for p in extra]==[36,37] and
            all(p['free_prime_count']==0 and tuple(p['normalized']) not in old_shapes for p in extra),
            'two new singleton shapes')
    require([(p['lambda'],p['core']) for p in extra]==[('4/19',19**4),('0',1)], 'singleton cores')
    require([p['center'] for p in protocol['windows']]==[found[0][0]]+[p['witness'][0] for p in extra],
            'predeclared window mapping')
    windows=[];distinct=set()
    for item in protocol['windows']:
        h=item['center'];low=max(cfg['start'],h-512);high=min(cfg['end'],h+512)
        records=[];hits=[]
        for n in range(low,high+1):
            a=o.derivative(n);b=o.derivative(a);q=n*n+a*a+b*b;r=math.isqrt(q)
            accept=a>0 and b>0 and r*r==q
            records.append([n,a,b,q,r,accept]);distinct.add(n)
            if accept:hits.append((n,a,b,r))
        require(hits==[row for row in found if low<=row[0]<=high], 'window/sealed projection')
        require(len(records)==high-low+1==item['requested_count']==1025, 'window actual count')
        windows.append({'center':h,'reason':item['reason'],'actual_bounds':[low,high],
            'requested_count':1025,'actual_count':len(records),'positive_count':len(hits),
            'negative_count':len(records)-len(hits),'columns':['n','D','D2','Q','floor_sqrt_Q','accept'],
            'records':records})
    require(sum(w['actual_count'] for w in windows)==len(distinct)==3075, 'distinct window inputs')
    raw_time=(run/'t11.tsv').read_bytes();measured=c.timings(raw_time)
    time_rows=[line.split() for line in raw_time.decode('ascii').splitlines()]
    require([row[0] for row in time_rows]==['11a.next']*2+['11b.next']*3 and
            all(row[-1]=='0' for row in time_rows), 'five successful recorded calls')
    prior_clock=c.timings((prior_dir/'snapshot/t11.tsv').read_bytes())
    require(measured['11a']==prior_clock['11a'] and measured['11c']==0 and
            raw_time.startswith((prior_dir/'snapshot/t11.tsv').read_bytes()), 'prior clock preservation')
    b_rows=[row for row in time_rows if row[0]=='11b.next']
    for clock,state in zip(b_rows,manifest):
        require(abs(Decimal(clock[1])-Decimal(state[4])/10**9)<Decimal('0.10'), 'elapsed/clock consistency')
    recovery=ROOT/'validation/11b_recovery_20261008/snapshot'
    require((run/'run.cfg').read_bytes()==(recovery/'run.cfg').read_bytes() and
            all((run/name).read_bytes()==(recovery/name).read_bytes() for name in
                ('s0000000000.tsv','s0000000000.sha256')) and
            raw_time.startswith((recovery/'t11.tsv').read_bytes()), 'first-segment recovery preserved')
    states={p['name']:p['inputs'] for p in plan['phases']};states.update({'11a':0,'11b':0})
    forecast=c.forecast(plan,states,measured,'11c',{'11a':True,'11b':True,'11c':False})
    require(forecast['status']=='PASS', 'conditional11c forecast')
    all_classes=inherited+positives
    shapes={tuple(p['normalized']) for p in all_classes}
    singleton=[p['i'] for p in all_classes if p['free_prime_count']==0]
    require(len(shapes)==10 and singleton==[2,8,11,28,36,37], 'observed class counts')
    print(json.dumps({'status':'PASS','sealed_to_end':True,'cfg_sha':identity,
        'native_interval':[cfg['start'],cfg['end']],'native_segments':len(manifest),
        'native_inputs':phase['inputs'],'native_positives':len(found),'native_negatives':phase['inputs']-len(found),
        'inherited_prefix_terms':nprior,'indexed_new_terms':[[p['i'],p['witness'][0]] for p in positives],
        'maximal_contiguous_terms':37,'first_unresolved_index':38,'first_unresolved_lower_bound_strict':cfg['end'],
        'positive_witnesses':positives,'planned_controls_recovered':len(controls),
        'additional_positive_count':len(extra),'new_infinite_same_shape_families':0,
        'primitive_shape_count':len(shapes),'singleton_indices':singleton,'infinite_class_member_terms':31,
        'windows':windows,'independent_window_distinct_inputs':len(distinct),
        'independent_window_positives':sum(w['positive_count'] for w in windows),
        'independent_window_negatives':sum(w['negative_count'] for w in windows),
        'call_wall_seconds':[float(row[1]) for row in b_rows],'wall_seconds':float(measured['11b']),
        'peak_rss_KiB':max(int(row[4]) for row in b_rows),'forecast_next_11c':forecast,
        'first_segment_recovery_preserved':True,
        'limitations':'Full negative coverage is reviewed C, not a second independent scan. Independent new negative scope3075 distinct inputs. Index baseline/P12/11a inherited. Singleton result applies to fixed primitive shape only, not every imaginable parameterization. No historical novelty, official continuation, publication or canonical campaign-input mutation.'},sort_keys=True,indent=2))


if __name__=='__main__':
    main()
