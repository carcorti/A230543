/* Test-only first-fsync failure. No production source changes. */
#include <errno.h>
int fsync(int fd) { (void)fd;errno=EIO;return -1; }
