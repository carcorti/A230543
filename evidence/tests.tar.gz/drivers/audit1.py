#!/usr/bin/env python3
"""Read-only P1 result audit; no search, build, campaign or b-file mutation.

Independent arithmetic is the existing Python trial-division oracle. SymPy
supplies an additional positive factorization; products and prime factors are
checked explicitly. Full-gap rejection relies on the reviewed C enumeration,
not on this 513-input bounded comparison. No checks rely on Python assertions.
"""
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('reference', ROOT/'validation/check.py')
oracle = importlib.util.module_from_spec(spec)
spec.loader.exec_module(oracle)
require = oracle.require


def exact_factors(n):
    import sympy
    factors = {int(p): int(e) for p, e in sympy.factorint(n).items()}
    require(math.prod(p**e for p, e in factors.items()) == n, 'factor product')
    for p, e in factors.items():
        require(p >= 2 and e > 0 and
                all(p % d for d in range(2, math.isqrt(p)+1)), 'factor primality')
    return factors


def main():
    import sympy
    run = Path(sys.argv[1]) if len(sys.argv) == 2 else ROOT/'runs/first'
    cfg = (run/'run.cfg').read_bytes()
    identity = hashlib.sha256(cfg).hexdigest()
    require(identity == '17de10b0ee4f28a483196d2cc2aff36ec7ebc49f80f95800bd99b04f6006cf60',
            'planned P1 configuration')
    fields = oracle.config(cfg)
    for key, path in [('source_sha', 'src/a230543.c'), ('makefile_sha', 'src/Makefile'),
                      ('binary_sha', 'src/a230543')]:
        require(hashlib.sha256((ROOT/path).read_bytes()).hexdigest() == fields[key],
                'current production identity: '+key)
    baseline = (ROOT/'data/b230543.txt').read_bytes()
    require(hashlib.sha256(baseline).hexdigest() == oracle.PREFIX_SHA, 'baseline identity')
    prefix = [tuple(map(int, line.split())) for line in baseline.splitlines() if line]
    require(len(prefix) == 22 and [i for i, _ in prefix] == list(range(1, 23)),
            'accepted prefix indices')
    require(fields['start'] == prefix[-1][1]+1, 'gapless prefix join')
    found = oracle.rows(run/'hits.tsv', True, identity)
    oracle.sealed_coverage(run, fields, identity, found)
    require(found and found[0][0] == 711541152 and len(found) == 1, 'observed P1 hit/boa')
    factors = []
    for row in found:
        require(oracle.witness(row[0]) == row, 'positive trial division')
        n, x1, x2, r = row
        fn, fa, fb = [exact_factors(value) for value in (n, x1, x2)]
        require(sum(e*(n//p) for p, e in fn.items()) == x1 and
                sum(e*(x1//p) for p, e in fa.items()) == x2 and
                n*n+x1*x1+x2*x2 == r*r, 'factor-derived witness')
        factors.append({'row': row, 'n_factors': fn, 'D_factors': fa,
                        'D2_factors': fb, 'Q': r*r})
    h = found[0][0]
    low, high = max(fields['start'], h-512), min(fields['end'], h+512)
    records, local_hits = [], []
    for n in range(low, high+1):
        a = oracle.derivative(n)
        b = oracle.derivative(a)
        q = n*n+a*a+b*b
        r = math.isqrt(q)
        accept = a > 0 and b > 0 and r*r == q
        records.append([n, a, b, q, r, accept])
        if accept:
            local_hits.append((n, a, b, r))
    projected = [row for row in found if low <= row[0] <= high]
    require(local_hits == projected, 'independent neighborhood/projection equality')
    require(len(records) == high-low+1 and len({row[0] for row in records}) == len(records),
            'actual and distinct input counts')
    print(json.dumps({
        'status': 'PASS', 'cfg_sha': identity, 'sealed_to_end': True,
        'native_scope': [fields['start'], fields['end']],
        'native_input_count': fields['end']-fields['start']+1,
        'native_negative_count': fields['end']-fields['start']+1-len(found),
        'accepted_baseline_sha': oracle.PREFIX_SHA, 'baseline_terms': len(prefix),
        'indexed_new_terms': [[len(prefix)+i+1, row[0]] for i, row in enumerate(found)],
        'positive_witnesses': factors,
        'positive_additional_method': 'SymPy factorint; trial-checked prime factors and exact product/derivative/square identities',
        'sympy_version': sympy.__version__,
        'sympy_module_sha': hashlib.sha256(Path(sympy.__file__).read_bytes()).hexdigest(),
        'neighborhood': {'requested_count': 1025, 'requested_bounds': [h-512, h+512],
                         'actual_bounds': [low, high], 'actual_count': len(records),
                         'distinct_count': len({row[0] for row in records}),
                         'positive_count': len(local_hits),
                         'negative_count': len(records)-len(local_hits),
                         'method': 'Python integer trial division and math.isqrt; independent of C',
                         'clipping': 'Upper boundary of P1; no inputs beyond END tested',
                         'columns': ['n', 'D', 'D2', 'Q', 'floor_sqrt_Q', 'accept'],
                         'records': records},
        'limitations': 'Only the bounded neighborhood is independently enumerated; full-gap exclusion uses reviewed exhaustive C coverage. Indexing inherits the accepted 22-term baseline. Hashes protect static local identities, not hostile rewriting. This is a result audit, not sustained performance qualification.'
    }, sort_keys=True, indent=2))


if __name__ == '__main__':
    main()
