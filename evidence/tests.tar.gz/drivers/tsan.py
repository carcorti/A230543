#!/usr/bin/env python3
"""One qualified LLVM/libomp/Archer configuration, fixed bounded regressions."""
import json
import os
from pathlib import Path
import sys
import hashlib
import shutil
import subprocess
from check import require,rows
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'validation/local_v1/tsan';OUT.mkdir(exist_ok=False)
EVENTS=[]
archer=Path('/usr/lib/llvm-18/lib/libarcher.so')
env={**os.environ,'OMP_TOOL':'enabled','OMP_TOOL_LIBRARIES':str(archer),'TSAN_OPTIONS':'ignore_noninstrumented_modules=1:halt_on_error=1:exitcode=66'}
(OUT/'environment.json').write_text(json.dumps({'environment':{k:env[k] for k in ['OMP_TOOL','OMP_TOOL_LIBRARIES','TSAN_OPTIONS']},'archer_sha256':hashlib.sha256(archer.read_bytes()).hexdigest(),'host':dict(zip(['system','node','release','version','machine'],os.uname()))},indent=2)+'\n')
def run(args,wanted=0):
 p=subprocess.run(list(map(str,args)),text=True,capture_output=True,env=env,timeout=60,cwd=ROOT)
 EVENTS.append({'command':list(map(str,args)),'exit':p.returncode,'expected':wanted,'stdout':p.stdout,'stderr':p.stderr});(OUT/'events.json').write_text(json.dumps(EVENTS,indent=2)+'\n')
 require(p.returncode==wanted,str(args)+p.stderr[-800:]);return p
flags='-O1 -g -std=c17 -Wall -Wextra -Werror -fopenmp=libomp -fsanitize=thread -fno-omit-frame-pointer'
run(['clang-18',*flags.split(),ROOT/'validation/tsan_controls.c','-o',OUT/'controls'])
run([OUT/'controls','startup']);p=run([OUT/'controls','clean']);require('WARNING' not in p.stderr,'race-free noise')
p=run([OUT/'controls','race'],66);require('data race' in p.stderr and 'tsan_controls.c:' in p.stderr,'source-located race sensitivity')
build=OUT/'build';build.mkdir()
for name in ['a230543.c','Makefile']:shutil.copyfile(ROOT/'src'/name,build/name)
run(['make','-C',build,'CC=clang-18','CFLAGS='+flags,'LDFLAGS=-fopenmp=libomp -fsanitize=thread'])
exe=build/'a230543';reference=rows(ROOT/'validation/local_v1/matrix/small_t1/hits.tsv',True)
for tag,lo,hi,threads,block,group in [('small1',2,32769,1,16384,2),('small4',2,32769,4,16384,2),('small8',2,32769,8,16384,1),('wide',988849240213842,988849240213842,4,16384,1)]:
 d=OUT/tag;run([exe,'init',d,lo,hi,block,group,threads]);run([exe,'next',d])
 if group==1 and tag=='small8':run([exe,'next',d])
 run([exe,'verify',d]);require(rows(d/'hits.tsv',True)==(reference if tag!='wide' else [rows(ROOT/'validation/reference.tsv')[-1]]),'candidate output')
require(all('WARNING: ThreadSanitizer' not in x['stderr'] for x in EVENTS if x['expected']==0),'candidate TSan noise')
(OUT/'summary.json').write_text(json.dumps({'status':'E / PASS','configuration':'LLVM18/libomp/Archer','source_sha256':hashlib.sha256((ROOT/'src/a230543.c').read_bytes()).hexdigest(),'controls':'startup normal; synchronized silent; deliberate source race detected exit66','candidate':'1/4/8-thread bounded enumeration + wide positive silent'},indent=2)+'\n')
print('QUALIFIED TSAN PASS')
