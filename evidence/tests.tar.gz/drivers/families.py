#!/usr/bin/env python3
"""Read-only exact recheck of all observed classes and the finite prime screen."""
from fractions import Fraction
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('oracle',ROOT/'validation/check.py')
o = importlib.util.module_from_spec(spec); spec.loader.exec_module(o)
spec = importlib.util.spec_from_file_location('factor',ROOT/'validation/p1_20261007/audit.py')
f = importlib.util.module_from_spec(spec); spec.loader.exec_module(f)
require = o.require
classes = json.loads((HERE/'classes.json').read_text())['rows']
require([row['i'] for row in classes] == list(range(1,31)), 'observed indices')
for row in classes:
    witness = tuple(row['witness']); n,a,b,r = witness
    require(o.witness(n) == witness, 'independent witness')
    g = math.gcd(*witness); m,u,v,w = (x//g for x in witness)
    require(row['gcd'] == g and row['normalized'] == [m,u,v,w], 'primitive shape')
    lam = Fraction(u-o.derivative(m),m)
    require(str(lam) == row['lambda'] and Fraction(o.derivative(g),g) == lam,
            'logarithmic scale')
    require(o.derivative(u)+lam*u == v, 'second normalized chain')
    den = f.exact_factors(lam.denominator)
    require(all(e == 1 for e in den.values()), 'squarefree denominator')
    residues = {p:(lam.numerator*pow(lam.denominator//p,-1,p))%p for p in den}
    alpha = sum((Fraction(e,p) for p,e in residues.items()),Fraction(0))
    core = math.prod(p**e for p,e in residues.items()); k = lam-alpha
    require(k.denominator == 1 and k >= 0 and core == row['core'] and
            str(alpha) == row['core_rate'] and k == row['free_prime_count'],
            'rational modular core and free degree')
    params = row['prime_parameters']
    require(len(params) == k and core*math.prod(p**p for p in params) == g,
            'prime parameter reconstruction')
require([row['i'] for row in classes if row['free_prime_count'] == 0] == [2,8,11,28],
        'observed singleton classification')
pattern = json.loads((HERE/'pattern.json').read_text())
primes = [p for p in range(2,1001) if all(p%d for d in range(2,math.isqrt(p)+1))]
require([row['p'] for row in pattern['records']] == primes and len(primes) == 168,
        'actual exhaustive prime-screen inputs')
for row in pattern['records']:
    n = 187*row['p']**4; a = o.derivative(n); b = o.derivative(a)
    q = n*n+a*a+b*b; r = math.isqrt(q)
    require([row['n'],row['D'],row['D2'],row['root_floor']] == [n,a,b,r] and
            row['accept'] == (r*r == q), 'direct screen arithmetic')
require([row['p'] for row in pattern['records'] if row['accept']] == [71],
        'finite positive prime-screen result')
print(json.dumps({'status':'PASS','class_inputs':30,'prime_screen_distinct_inputs':168,
                  'singleton_indices':[2,8,11,28],'family_terms_through27':24,
                  'method':'Direct trial derivative plus independent rational modular residue reconstruction; finite results and explicit proof have distinct scopes'}))
