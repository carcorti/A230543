#!/usr/bin/env python3
"""Read-only launch control: frozen identities, prior archive and time forecast.

Never runs init/next, edits configs, expands budgets or rebuilds production.
Forecasts are planning estimates, not guarantees. Carlo monitors live runtime.
"""
import argparse
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def native_status(raw, phase, binary_sha):
    """Parse do_status output, including ready and unsealed checkpoints.

    Native status audits its files first. Remaining=0 alone is not a seal.
    """
    require(raw.endswith('\n') and '\r' not in raw and '\0' not in raw,
            'native status framing')
    lines = raw.splitlines()
    require(len(lines) == 2, 'native status line count')
    match = re.fullmatch(
        r'A230543 STATUS: target=\[([0-9]+),([0-9]+)\] '
        r'sealed_segments=([0-9]+) sealed_frontier=([0-9]+) '
        r'checkpoint_frontier=([0-9]+) remaining=([0-9]+) '
        r'hits=([0-9]+) elapsed_ns=([0-9]+) '
        r'cfg_sha=([0-9a-f]{64}) bin_sha=([0-9a-f]{64})', lines[0])
    require(match is not None, 'native status header grammar')
    start, end, sealed, seal_frontier, checkpoint, remaining = map(int, match.groups()[:6])
    require((start,end) == (phase['start'],phase['end']) and
            match[9] == phase['expected_config_sha256'] and match[10] == binary_sha,
            'native status identity')
    width = phase['block']*phase['group']
    segments = (end-start+width)//width
    require(0 <= sealed <= segments and
            seal_frontier == min(end,start-1+sealed*width) and
            seal_frontier <= checkpoint <= min(end,seal_frontier+width) and
            remaining == end-checkpoint, 'native status frontier consistency')
    if lines[1] == 'COMPLETE':
        require(sealed == segments and checkpoint == end, 'native completion without final seal')
        return remaining, True
    require(sealed < segments, 'native incomplete state after final seal')
    ready = re.fullmatch(r'NEXT segment=([0-9]+) from=([0-9]+)', lines[1])
    if ready is not None:
        require(int(ready[1]) == sealed and int(ready[2]) == checkpoint+1 and
                checkpoint == seal_frontier, 'native NEXT frontier consistency')
    else:
        partial = re.fullmatch(
            r'INCOMPLETE segment=([0-9]+) next_block=([0-9]+) '
            r'\(unsealed state; only earlier sealed segments certify an aggregate interval\)',
            lines[1])
        require(partial is not None, 'unexpected native state')
        require(int(partial[1]) == sealed and int(partial[2]) == checkpoint+1,
                'native INCOMPLETE frontier consistency')
        require(checkpoint == end or (checkpoint-(start-1)) % phase['block'] == 0,
                'native incomplete block boundary')
    return remaining, False


def timings(raw):
    result = {name: Decimal(0) for name in ('11a','11b','11c')}
    require((not raw or raw.endswith(b'\n')) and b'\r' not in raw and b'\0' not in raw,
            'timing LF framing')
    for row in raw.decode('ascii').splitlines():
        match = re.fullmatch(r'(11[abc])\.next ([0-9]+(?:\.[0-9]+)?) ([0-9]+(?:\.[0-9]+)?) ([0-9]+(?:\.[0-9]+)?) ([0-9]+) ([0-9]+)', row)
        require(match is not None, 'timing grammar: preserve and diagnose')
        require(int(match[6]) in (0,2,130,137,143), 'unexpected next exit: diagnose before continuing')
        result[match[1]] += Decimal(match[2])
    return result


def forecast(plan, states, measured, selected=None, complete=None):
    if complete is None:
        complete = {name:remaining == 0 for name,remaining in states.items()}
    rates = [plan['slow_reference_rate']]
    remaining_total = 0
    for phase in plan['phases']:
        name = phase['name']; remaining = states[name]
        require(0 <= remaining <= phase['inputs'], 'remaining range')
        covered = phase['inputs']-remaining
        require(not covered or measured[name] > 0, 'covered work has no timing record: budget unknown')
        if covered and measured[name] > 0:
            rates.append(covered/float(measured[name]))
        remaining_total += remaining
    rate = min(rates)
    used = float(sum(measured.values()))
    fixed = plan['past_P12_next_seconds']+plan['planning_pilot_seconds']+plan['non_next_allowance_seconds']
    projection = fixed+used+remaining_total/rate
    result = {'status':'PASS' if projection <= plan['user_budget_seconds'] else 'STOP_REASSESS',
              'recorded_P3_next_seconds':used,'remaining_inputs':remaining_total,
              'effective_conservative_model_rate':rate,'forecast_cumulative_seconds':projection,
              'forecast_cumulative_hours':projection/3600,'budget_hours':plan['user_budget_seconds']/3600,
              'scope':'P1/P2 recorded next time plus pilots, P3 recorded next time, estimated remaining scan and reserved non-next allowance; idle time excluded; not a guaranteed bound'}
    if selected:
        phase = next(p for p in plan['phases'] if p['name'] == selected)
        index = [p['name'] for p in plan['phases']].index(selected)
        require(all(complete[p['name']] for p in plan['phases'][:index]), 'seal and audit earlier phases first')
        require(not complete[selected], 'selected phase already complete: do not repeat next')
        result['selected_phase'] = selected
        selected_rate = phase['rate_reference']
        covered = phase['inputs']-states[selected]
        if covered and measured[selected] > 0:
            selected_rate = min(selected_rate,covered/float(measured[selected]))
        width = phase['block']*phase['group']
        call_inputs = min(states[selected],width-covered%width)
        result['selected_call_rate_model'] = selected_rate
        result['next_remaining_call_inputs'] = call_inputs
        result['next_remaining_call_seconds_estimate'] = call_inputs/selected_rate
        if result['next_remaining_call_seconds_estimate']+plan['per_call_closure_seconds'] > 3600:
            result['status'] = 'STOP_REASSESS'
            result['reason'] = 'Observed slowdown makes the next immutable segment exceed the planned hourly envelope.'
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--next', choices=['11a','11b','11c'], dest='selected')
    args = parser.parse_args()
    cp = subprocess.run(['python3','outputs/A230543_cli_preflight_20261006.py'],cwd=ROOT,capture_output=True,text=True,timeout=10)
    require(cp.returncode == 0, cp.stdout+cp.stderr)
    cp = subprocess.run(['sha256sum','--check','--status','outputs/A230543_1E11_inputs.sha256'],cwd=ROOT,capture_output=True,text=True,timeout=10)
    require(cp.returncode == 0, 'new campaign inputs changed: run sha256sum --check to diagnose')
    cp = subprocess.run(['sha256sum','--check','--status','runs/run.sha256'],cwd=ROOT,capture_output=True,text=True,timeout=10)
    require(cp.returncode == 0, 'prior P1/P2 archive changed')
    plan = json.loads((ROOT/'outputs/A230543_1E11_plan.json').read_text())
    states = {}
    complete = {}
    for phase in plan['phases']:
        path = ROOT/phase['directory']
        require(not path.is_symlink(), 'phase directory symlink')
        if not path.exists():
            states[phase['name']] = phase['inputs']
            complete[phase['name']] = False
            continue
        require(hashlib.sha256((path/'run.cfg').read_bytes()).hexdigest() == phase['expected_config_sha256'], 'phase config identity')
        cp = subprocess.run(['./src/a230543','status',phase['directory']],cwd=ROOT,capture_output=True,text=True,timeout=10)
        require(cp.returncode == 0, cp.stdout+cp.stderr)
        states[phase['name']], complete[phase['name']] = native_status(cp.stdout,phase,plan['binary_sha'])
    path = ROOT/plan['new_time_file']
    measured = timings(path.read_bytes() if path.exists() else b'')
    result = forecast(plan,states,measured,args.selected,complete)
    print(json.dumps(result,indent=2))
    if result['status'] != 'PASS':
        raise SystemExit(2)


if __name__ == '__main__':
    try:
        main()
    except (OSError,ValueError,KeyError,RuntimeError,subprocess.SubprocessError) as error:
        raise SystemExit('CONTROL FAIL: '+str(error))
