#!/usr/bin/env python3
"""Read-only final audit on frozen copies (or --live); never invokes C next.

Independent negative coverage is bounded; full negative coverage is inherited
reviewed-C enumeration, freshly reconciled to all sealed segments.
"""
import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, ROOT/path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


b = load('prior11b', 'validation/11b_20261008/audit.py')
o, c = b.o, b.c
require = o.require
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--live', action='store_true')
    args = parser.parse_args()
    runroot = ROOT/'runs' if args.live else HERE/'snapshot'
    protocol = json.loads((HERE/'protocol.json').read_text())
    plan = json.loads((ROOT/'outputs/A230543_1E11_plan.json').read_text())
    identities = [('first', '17de10b0ee4f28a483196d2cc2aff36ec7ebc49f80f95800bd99b04f6006cf60'),
                  ('1E10', 'daeacf098b33e720642e8cfeadf29190a87ad9167db4f070cb2ca3a43f7ce86b')]
    identities += [(p['name'], p['expected_config_sha256']) for p in plan['phases']]
    baseline = (HERE/'baseline22.txt').read_bytes()
    require(hashlib.sha256(baseline).hexdigest() == o.PREFIX_SHA, 'accepted22 identity')
    known = [tuple(map(int, r.split())) for r in baseline.splitlines() if r]
    require(len(known) == 22 and [i for i,n in known] == list(range(1,23)), 'accepted22 indices')
    baseline_classes = json.loads((ROOT/'validation/family_r2_20261007/classes.json').read_text())['rows']
    require([(p['i'], p['witness'][0]) for p in baseline_classes[:22]] == known, 'accepted22 witnesses')
    for p in baseline_classes[:22]:
        require(o.witness(p['witness'][0]) == tuple(p['witness']), 'baseline membership')
    controls = {tuple(p['witness']) for p in json.loads(
        (ROOT/'validation/p3_plan_20261007/witnesses.json').read_text())['rows']}
    frontier = known[-1][1]
    all_found, phases = [], []
    for name, identity in identities:
        run = runroot/name
        require(sha(run/'run.cfg') == identity, 'run identity: '+name)
        cfg = o.config((run/'run.cfg').read_bytes())
        require(cfg['start'] == frontier+1, 'gapless scan join: '+name)
        for key, path in [('source_sha','src/a230543.c'),('makefile_sha','src/Makefile'),
                          ('binary_sha','src/a230543')]:
            require(cfg[key] == plan[key] == sha(ROOT/path), 'production identity: '+name)
        found = o.rows(run/'hits.tsv', True, identity)
        o.sealed_coverage(run, cfg, identity, found)
        require(all(cfg['start'] <= r[0] <= cfg['end'] and o.witness(r[0]) == r for r in found),
                'independent membership/domain: '+name)
        records = [r.split('\t') for r in o.lines((run/'manifest.tsv').read_bytes())[2:]]
        if name.startswith('11'):
            planned = next(p for p in plan['phases'] if p['name'] == name)
            require(all(cfg[k] == planned[k] for k in ('start','end','block','group','threads')),
                    'planned config: '+name)
            require(len(records) == planned['segments'], 'planned segment count')
        phases.append({'name':name, 'cfg_sha':identity, 'bounds':[cfg['start'],cfg['end']],
                       'segments':len(records), 'inputs':cfg['end']-cfg['start']+1,
                       'positives':len(found), 'elapsed_ns':sum(int(r[4]) for r in records)})
        all_found.extend(found)
        frontier = cfg['end']
    require(frontier == 10**11 and len(all_found) == 17 and
            sum(p['segments'] for p in phases) == 17, 'full campaign terminal state')
    classes = baseline_classes[:22] + [b.classify(23+i, r, controls) for i,r in enumerate(all_found)]
    entries = known + [(23+i,r[0]) for i,r in enumerate(all_found)]
    require(len(entries) == 39 and all(a[1] < z[1] for a,z in zip(entries,entries[1:])), 'contiguous39')
    inherited_dir = ROOT/'validation/11b_20261008'
    inherited = [tuple(map(int,r.split())) for r in (inherited_dir/'b230543.txt').read_bytes().splitlines() if r]
    require(entries[:37] == inherited and [r[1] for r in entries[37:]] == protocol['observed_new_terms'],
            'exact37 prefix/new38-39')
    prior_witnesses = [tuple(map(int,r.split())) for r in
                      (inherited_dir/'witnesses.tsv').read_text().splitlines()[1:] if r]
    require([(p['i'],*p['witness']) for p in classes[:37]] == prior_witnesses, 'prior witnesses unchanged')
    new = classes[37:]
    require([p['normalized'] for p in new] == [[99,372,1624,1669],[2,9,42,43]] and
            [p['prime_parameters'] for p in new] == [[3,3,7],[2,2,5,7]] and
            all(p['planned_control'] for p in new), 'F3/F4 planned controls')
    windows = []
    for item in protocol['independent_windows']:
        low, high = item['center']-512, item['center']+512
        require(phases[-1]['bounds'][0] <= low <= high <= frontier, 'fresh window bounds')
        records, hits = [], []
        for n in range(low, high+1):
            a = o.derivative(n); d2 = o.derivative(a); q = n*n+a*a+d2*d2; r = math.isqrt(q)
            accept = a > 0 and d2 > 0 and r*r == q
            records.append([n,a,d2,q,r,accept])
            if accept: hits.append((n,a,d2,r))
        require(hits == [r for r in all_found if low <= r[0] <= high], 'fresh independent window projection')
        require(len(records) == item['requested_count'] == 1025, 'actual/requested window count')
        windows.append({**item,'actual_bounds':[low,high],'actual_count':len(records),
                        'positive_count':len(hits),'negative_count':len(records)-len(hits),
                        'columns':['n','D','D2','Q','floor_sqrt_Q','accept'],'records':records})
    inherited_windows = [json.loads((ROOT/'validation/p1_20261007/result.json').read_text())['neighborhood']]
    for path in ('validation/p12_20261007/result.json', 'validation/11a_20261007/result.json',
                 'validation/11b_20261008/result.json'):
        report = json.loads((ROOT/path).read_text()); require(report['status'] == 'PASS', 'inherited window result')
        inherited_windows += report['windows']
    union = {}
    for window in inherited_windows + windows:
        records = window['records']; low, high = window['actual_bounds']
        require([r[0] for r in records] == list(range(low,high+1)) and
                len(records) == window['actual_count'] and
                sum(r[-1] for r in records) == window['positive_count'], 'raw window coverage/counts')
        for rec in records:
            n,a,d2,q,r,accept = rec
            require(q == n*n+a*a+d2*d2 and r*r <= q < (r+1)**2 and
                    accept == (a>0 and d2>0 and r*r==q), 'raw inherited integer square record')
            require(n not in union or union[n] == rec, 'overlapping oracle disagreement')
            union[n] = rec
    require(len(union) == 9738 and sum(r[-1] for r in union.values()) == 10,
            'campaign distinct bounded windows')
    raw_clock = (runroot/'t11.tsv').read_bytes()
    measured = c.timings(raw_clock)
    clock = [r.split() for r in raw_clock.decode('ascii').splitlines()]
    require([r[0] for r in clock] == ['11a.next']*2+['11b.next']*3+['11c.next']*8 and
            all(r[-1] == '0' for r in clock), '13 successful calls')
    for phase in plan['phases']:
        manifest = [r.split('\t') for r in o.lines((runroot/phase['name']/'manifest.tsv').read_bytes())[2:]]
        recorded = [r for r in clock if r[0] == phase['name']+'.next']
        for timing, segment in zip(recorded, manifest):
            require(abs(Decimal(timing[1])-Decimal(segment[4])/10**9) < Decimal('0.10'), 'clock/seal alignment')
    require(raw_clock.startswith((inherited_dir/'snapshot/t11.tsv').read_bytes()), 'prior timing prefix')
    recovery = ROOT/'validation/11c_recovery_20261008/snapshot'
    for name in ('run.cfg','s0000000000.tsv','s0000000000.sha256'):
        require((runroot/'11c'/name).read_bytes() == (recovery/name).read_bytes(), 'first11c recovery preservation')
    require(raw_clock.startswith((recovery/'t11.tsv').read_bytes()), 'first11c clock preservation')
    old_clock = [r.split() for r in (runroot/'time.tsv').read_text().splitlines()]
    require([r[0] for r in old_clock] == ['P1.next']+['P2.next']*3 and all(r[-1]=='0' for r in old_clock), 'P12 clock')
    past = sum(Decimal(r[1]) for r in old_clock)
    require(abs(past-Decimal(str(plan['past_P12_next_seconds']))) < Decimal('0.00001'), 'P12 model clock')
    forecast = c.forecast(plan,{p['name']:0 for p in plan['phases']}, measured,
                          complete={p['name']:True for p in plan['phases']})
    require(forecast['status'] == 'PASS', 'budget envelope')
    singleton = [p['i'] for p in classes if p['free_prime_count'] == 0]
    require(singleton == [2,8,11,28,36,37] and len({tuple(p['normalized']) for p in classes}) == 10,
            'final class inventory')
    # Existing proved lambda=1 relation: replay at p=2, then check p=3.
    primitive = (4802517313,5246382600,19023654540,20309803913)
    require(o.witness(primitive[0]*4) == tuple(x*4 for x in primitive), 'lambda1 known-case replay')
    sparse = tuple(x*27 for x in primitive)
    require(sparse[0] == 129667967451 and o.witness(sparse[0]) == sparse and sparse[0] > frontier,
            'exact sparse upper bound for next index')
    bfile = ''.join(f'{i} {n}\n' for i,n in entries).encode('ascii') + b'\n'
    witnesses = ('i\tn\tD\tD2\troot\n' + ''.join(
        '\t'.join(map(str,(p['i'],*p['witness'])))+'\n' for p in classes)+'\n').encode('ascii')
    require(bfile.startswith(baseline[:-1]) and bfile.endswith(b'\n\n') and
            not bfile.endswith(b'\n\n\n'), 'canonical framing/common prefix')
    total = sum(measured.values())+past
    result = {'status':'PASS','maximal_contiguous_terms':39,'indexed_new_terms':entries[37:],
              'accepted_baseline_terms':22,'phases':phases,'scanned_interval':[known[-1][1]+1,frontier],
              'native_inputs':frontier-known[-1][1],'native_new_positives':17,
              'native_negatives':frontier-known[-1][1]-17,'positive_witnesses':new,
              'all_classes':classes,'primitive_shape_count':10,'singleton_indices':singleton,
              'infinite_class_member_terms':33,'windows':windows,'fresh_independent_inputs':2050,
              'fresh_independent_positives':2,'fresh_independent_negatives':2048,
              'campaign_bounded_distinct_inputs':len(union),'campaign_bounded_positives':10,
              'campaign_bounded_negatives':len(union)-10,'P3_next_seconds':float(sum(measured.values())),
              'P12_next_seconds':float(past),'all_recorded_next_seconds':float(total),
              '11c_call_wall_seconds':[float(r[1]) for r in clock[5:]],
              '11c_wall_seconds':float(measured['11c']),'P3_peak_rss_KiB':max(int(r[4]) for r in clock),
              'budget_envelope':forecast,'bfile_sha256':hashlib.sha256(bfile).hexdigest(),
              'witnesses_sha256':hashlib.sha256(witnesses).hexdigest(),
              'endpoint':{'status':'ENDPOINT DISCOVERY PASS','first_unresolved_index':40,
                          'strict_lower_bound':frontier,'exact_upper_bound':sparse[0],
                          'sparse_witness':sparse,'relation':'proved lambda1 scaling p^p; replay p2 and check p3',
                          'unmet_dependency':'negative coverage on [100000000001,129667967450] or a new exact ordering proof',
                          'terminal_challenge':'No farther contiguous index follows from admitted current evidence.'},
              'limitations':'Full negative coverage is reviewed C enumeration, freshly checked against seals; not an independent second full scan. Prior bounded windows inherited with exact raw-record reconciliation. Current public OEIS retrieval unavailable; accepted22 local baseline pinned. Fixed-shape singleton classification does not exclude other parameterizations. No official continuation, remote publication or OEIS submission.'}
    print(json.dumps(result,sort_keys=True,indent=2))


if __name__ == '__main__':
    main()
