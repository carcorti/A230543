#!/usr/bin/env python3
"""Bounded private hardening, exact identity and explicit expected failures.
This is a local driver, not an official campaign launcher.
"""
import hashlib
import json
import math
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import time
from check import rows, witness, require
import sympy

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'validation/local_v1/matrix'
EXE=ROOT/'src/a230543'
EVENTS=[]

def run(args, expected=0, timeout=30, env=None, input=None):
    command=list(map(str,args)); t=time.monotonic()
    p=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=timeout,env=env,input=input)
    event={'command':command,'expected':expected,'exit':p.returncode,'seconds':time.monotonic()-t,'stdout':p.stdout,'stderr':p.stderr}
    EVENTS.append(event)
    (OUT/'events.json').write_text(json.dumps(EVENTS,indent=2)+'\n')
    require(p.returncode==expected, str(command)+': '+p.stderr[-1000:])
    return p

def init(tag, low, high, block=16384, group=1, threads=1, exe=EXE, env=None):
    d=OUT/tag
    run([exe,'init',d,low,high,block,group,threads],env=env)
    return d

def complete(d,exe=EXE,env=None):
    while True:
        p=run([exe,'next',d],env=env)
        if 'already sealed' in p.stdout: break
    run([exe,'verify',d],env=env)
    return rows(d/'hits.tsv',True)

def variant(tag,cc,cflags,ldflags):
    d=OUT/tag;d.mkdir()
    for name in ['a230543.c','Makefile']: shutil.copyfile(ROOT/'src'/name,d/name)
    run(['make','-C',d,'CC='+cc,'CFLAGS='+cflags,'LDFLAGS='+ldflags],timeout=60)
    return d/'a230543'

def fingerprint(d):
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in d.iterdir() if p.is_file()}

def change_segment(d,fn):
    path=d/'s0000000000.tsv'
    prefix=path.read_bytes()[:-75]
    prefix=fn(prefix)
    path.write_bytes(prefix+b'state_sha\t'+hashlib.sha256(prefix).hexdigest().encode()+b'\n')
    seal=d/'s0000000000.sha256'
    digest=hashlib.sha256(path.read_bytes()).hexdigest()
    old=seal.read_text()
    seal.write_text(digest+old[64:])

def corruption(base):
    mutations={
      'nul':lambda b:b.replace(b'A230543-SEG-2\n',b'A230543-SEG-2\0junk\n'),
      'old_magic':lambda b:b.replace(b'A230543',b'A249106',1),
      'root_zero':lambda b:b.replace(b'512\t2304\t10752\t11008',b'512\t2304\t10752\t0'),
      'bad_root':lambda b:b.replace(b'512\t2304\t10752\t11008',b'512\t2304\t10752\t11009'),
      'bad_derivative':lambda b:b.replace(b'512\t2304\t10752',b'512\t2305\t10752'),
      'six_columns':lambda b:b.replace(b'512\t2304\t10752\t11008',b'512\t2304\t10752\t11008\t1\t2'),
      'crlf':lambda b:b.replace(b'\n',b'\r\n'),
      'frontier':lambda b:b.replace(b'frontier\t32769',b'frontier\t32768'),
      'unordered':lambda b:b.replace(b'512\t2304\t10752\t11008',b'1203\t404\t408\t1333'),
    }
    for tag,fn in mutations.items():
        d=OUT/('corrupt_'+tag);shutil.copytree(base,d);change_segment(d,fn)
        run([EXE,'verify',d],expected=1)
    for tag,fn in {'cfg_nul':lambda b:b.replace(b'A230543-CFG-1\n',b'A230543-CFG-1\0hidden\n'),
                   'cfg_extra':lambda b:b+b'extra\n','cfg_crlf':lambda b:b.replace(b'\n',b'\r\n')}.items():
        d=OUT/tag;shutil.copytree(base,d);p=d/'run.cfg';p.write_bytes(fn(p.read_bytes()))
        run([EXE,'verify',d],expected=1)
    d=OUT/'truncated';shutil.copytree(base,d);p=d/'s0000000000.tsv';p.write_bytes(p.read_bytes()[:-1]);run([EXE,'verify',d],expected=1)
    d=OUT/'future';shutil.copytree(base,d);shutil.copyfile(d/'s0000000000.tsv',d/'s0000000002.tsv');run([EXE,'verify',d],expected=1)
    d=OUT/'aggregate_changed';shutil.copytree(base,d);p=d/'hits.tsv';p.write_bytes(p.read_bytes().replace(b'11008',b'11009'));run([EXE,'verify',d],expected=1)
    d=OUT/'repair';shutil.copytree(base,d)
    for f in ['hits.tsv','manifest.tsv']:
        p=d/f; p.write_text(''.join(p.read_text().splitlines(keepends=True)[:2]))
    run([EXE,'verify',d],expected=2);run([EXE,'next',d]);run([EXE,'verify',d]);require(rows(d/'hits.tsv',True)==rows(base/'hits.tsv',True),'aggregate repair')
    d=OUT/'recover_seal';shutil.copytree(base,d);(d/'s0000000000.sha256').unlink()
    for f in ['hits.tsv','manifest.tsv']:
        p=d/f;p.write_text(''.join(p.read_text().splitlines(keepends=True)[:2]))
    run([EXE,'verify',d],expected=2);run([EXE,'next',d]);run([EXE,'verify',d])
    require(rows(d/'hits.tsv',True)==rows(base/'hits.tsv',True),'seal recovery')

def backend():
    flags=['-O2','-std=c17','-Wall','-Wextra','-Werror','-fopenmp']
    run(['gcc',*flags,ROOT/'validation/backend_probe.c','-o',OUT/'probe','-lgmp','-lcrypto'])
    run([OUT/'probe','bounds'])
    run(['gcc',*flags,'-DA230543_FORCE_FALLBACK',ROOT/'validation/backend_probe.c','-o',OUT/'probe_fallback','-lgmp','-lcrypto'])
    rng=random.Random(230543)
    corpus={1,2,3,4,97,101,10403,3215031751,341550071728321,3825123056546413051,2**64-1,2**64-59,265000000000000000}
    corpus.update(rng.randrange(2,10**12) for _ in range(128))
    corpus.update(x for n in [2,101,1009,10007] for x in [n*n,n**3] if x<2**64)
    p=run([OUT/'probe'],input=''.join(str(n)+'\n' for n in sorted(corpus)),timeout=60)
    for line in p.stdout.splitlines():
        n,prime,d,fb=map(int,line.split('\t'));f=sympy.factorint(n)
        expected=sum(int(e)*(n//int(q)) for q,e in f.items())
        require(prime==int(sympy.isprime(n)) and d==expected,'factor oracle '+str(n))
    p=run([OUT/'probe_fallback'],input='10403\n10201\n1000036000099\n',timeout=60)
    for line in p.stdout.splitlines():
        n,prime,d,fb=map(int,line.split('\t'));f=sympy.factorint(n)
        require(d==sum(int(e)*(n//int(q)) for q,e in f.items()) and fb==1,'fallback exactness')
    print('backend independent factor checks PASS',flush=True)

def interruptions():
    # Nonzero interval; 8 small blocks. Poll atomic state, not inferred progress.
    low=20000001;block=65536;high=low+8*block-1
    full=init('stop_full',low,high,block,8);expected=complete(full)
    records=[]
    for tag,target,signum in [('zero',0,signal.SIGINT),('one',1,signal.SIGTERM),('multiple',2,signal.SIGINT)]:
        d=init('stop_'+tag,low,high,block,8)
        p=subprocess.Popen([str(EXE),'next',str(d)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,cwd=ROOT)
        first=p.stderr.readline();require(first.startswith('START '),'stop START')
        deadline=time.monotonic()+30
        if target:
            while time.monotonic()<deadline and p.poll() is None:
                try: text=(d/'s0000000000.tsv').read_text()
                except FileNotFoundError: text=''
                if 'frontier\t'+str(low+target*block-1)+'\n' in text:break
                time.sleep(.001)
            else:
                p.kill();p.communicate();raise RuntimeError('checkpoint stop deadline')
        p.send_signal(signum);out,err=p.communicate(timeout=30)
        require(p.returncode==2,'stop exit')
        state=d/'s0000000000.tsv'
        frontier=int(dict(line.split('\t',1) for line in state.read_text().splitlines()[1:8])['frontier']) if state.exists() else low-1
        require(frontier==low+target*block-1,'stop durable frontier')
        require(not (d/'s0000000000.sha256').exists(),'partial seal forbidden')
        run([EXE,'verify',d],expected=2)
        records.append({'state':tag,'frontier':frontier,'blocks':target,'signal':int(signum),'exit':p.returncode,'stdout':out,'stderr':first+err,'before_resume':fingerprint(d)})
        require(complete(d)==expected,'stop resume disagreement')
    (OUT/'stop_matrix.json').write_text(json.dumps(records,indent=2)+'\n')
    print('zero/one/multiple/full stop matrix PASS',flush=True)

def late(oracle):
    strict='-O2 -g -std=c17 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Wdouble-promotion -Wformat=2 -Werror'
    clang=variant('clang','clang-18',strict+' -fopenmp=libomp','-fopenmp=libomp')
    sanitizer=variant('asan','clang-18',strict+' -fopenmp=libomp -fsanitize=address,undefined -fno-omit-frame-pointer','-fopenmp=libomp -fsanitize=address,undefined')
    for tag,exe in [('clang',clang),('asan',sanitizer)]:
        env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0:halt_on_error=1','UBSAN_OPTIONS':'halt_on_error=1'} if tag=='asan' else None
        d=init(tag+'_run',2,32769,16384,2,4,exe,env)
        require(complete(d,exe,env)==oracle,tag+' exact regression')
        d=init(tag+'_wide',988849240213842,988849240213842,threads=4,exe=exe,env=env)
        require(complete(d,exe,env)==[rows(ROOT/'validation/reference.tsv')[-1]],tag+' wide regression')
    run(['cppcheck','--enable=warning,performance,portability','--error-exitcode=1','--std=c17',ROOT/'src/a230543.c'])
    run(['clang-tidy',ROOT/'src/a230543.c','--','-std=c17','-fopenmp=libomp'])

def main():
    OUT.mkdir(exist_ok=False)
    identities={name:hashlib.sha256((ROOT/'src'/name).read_bytes()).hexdigest() for name in ['a230543.c','Makefile','a230543']}
    (OUT/'identity.json').write_text(json.dumps(identities,indent=2)+'\n')
    run(['python3',ROOT/'validation/check.py']);run(['python3','-O',ROOT/'validation/check.py'])
    oracle=None;base=None
    for t,g in [(1,2),(4,1),(8,2)]:
        d=init('small_t'+str(t),2,32769,16384,g,t);actual=complete(d)
        run(['python3',ROOT/'validation/check.py','--run',d,'--low',2,'--high',32769])
        run(['python3','-O',ROOT/'validation/check.py','--run',d,'--low',2,'--high',32769])
        if oracle is None: oracle=actual;base=d
        require(actual==oracle,'thread/group determinism')
    for i,row in enumerate(rows(ROOT/'validation/reference.tsv')):
        d=init('fixture_'+str(i),row[0],row[0],threads=4)
        require(complete(d)==[row],'singleton witness '+str(row[0]))
    for tag,lo,hi in [('shifted',490,6500),('boundary',16383,16385),('empty',2,3),('cap',10**16-1,10**16)]:
        d=init(tag,lo,hi,threads=4);complete(d)
        if hi<=10**10:run(['python3',ROOT/'validation/check.py','--run',d,'--low',lo,'--high',hi])
        else:run(['python3',ROOT/'validation/check.py','--run',d])
    for i,values in enumerate([(1,2,16384,1,1),(2,10**16+1,16384,1,1),(2,2,16383,1,1),(2,2,1048577,1,1),(2,2,32767,1,1),(2,2,16384,0,1),(2,2,16384,2**64,1),(2,2,16384,1,0),(2,2,16384,1,9),('-1',2,16384,1,1),('2x',2,16384,1,1)]):
        d=OUT/('invalid_'+str(i));run([EXE,'init',d,*values],expected=1);require(not d.exists(),'invalid init mutation')
    maximum=init('max_group',10**16,10**16,1048576,2**64-1,8);complete(maximum)
    before=fingerprint(base);run([EXE,'init',base,2,3,16384,1,1],expected=1);require(fingerprint(base)==before,'no clobber')
    for args in [[],['bad'],['next'],['verify',base,'extra'],['init']]:run([EXE,*args],expected=1)
    corruption(base);backend();interruptions()
    late(oracle)
    summary={'status':'PASS','source_identity':identities,'sympy':sympy.__version__,'commands':len(EVENTS),'independent_small_coverage':[2,32769],'fixtures':30,'scope':'bounded internal validation, not official extension or external review'}
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(json.dumps(summary),flush=True)

if __name__=='__main__':main()
